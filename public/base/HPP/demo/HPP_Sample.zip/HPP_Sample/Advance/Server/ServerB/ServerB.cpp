// ServerC.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <hpp/hpp_hpp.h>
#include <string>
#include <iostream>

#include "../msg/ReqA.pb.h"
#include "../msg/RspA.pb.h"
#include "../msg/ReqB.pb.h"
#include "../msg/RspB.pb.h"

enum _cmd
{
    CMD_REQ_A       = 100,
    CMD_REQ_B       = 101,
    CMD_RSP_A       = 102,
    CMD_RSP_B       = 103,
};

ConnSession* g_AHServiceConn = NULL;

//<�������Ľ�������
WrapIf* _CreateMessageByCmdId_ServerB(HPR_INT32 cmdId)
{
    std::cout << "_CreateMessageByCmdId_ServerB" << std::endl;

    WrapIf* p_wrap = NULL;	
    switch (cmdId)
    {
    case CMD_REQ_A:
        {
            p_wrap = PBWrapFactory<cms_8100::ReqA>::CreatePBWrap();
        }
        break;
    case CMD_RSP_B:
        {
            p_wrap = PBWrapFactory<cms_8100::RspB>::CreatePBWrap();
        }
        break;
    default:
        p_wrap = NULL;
    }
    return p_wrap;
}

template<> inline WrapIf* PBWrap<cms_8100::ReqA>::DoExecute()
{
    std::cout << "PBWrap<cms_8100::ReqA>::DoExecute()" << std::endl;

    std::cout<<"ServerB recv ReqA, srcID "<<GetWrapSrcId()<<" DstID "<<GetWrapDstId()<<std::endl; 

    cms_8100::ReqA & r_msg = GetMsg();
    std::cout<<r_msg.user_name().c_str()<<std::endl;

    if (g_AHServiceConn)
    {
        PBWrap<cms_8100::ReqB>* p_msg_wrap = PBWrapFactory<cms_8100::ReqB>::CreatePBWrap();
        if (p_msg_wrap == NULL)
        {
            std::cout << "CreatePBWrap fail ..." <<std::endl;
            return NULL;
        }
        //����HPPЭ��ͷ
        p_msg_wrap->SetCommandId(CMD_REQ_B);
        p_msg_wrap->SetInnerSequence(GetInnerSequence()/*HPP_GetUnRepeatSeq()*/);
        p_msg_wrap->SetMessageType(HPP_PACK_HEAD::REQ_MSG_NEED_RSP);//��Ҫ��Ӧ
        p_msg_wrap->SetWrapSrcId(GetWrapSrcId());//
        p_msg_wrap->SetWrapDstId(g_AHServiceConn->GetSessionId());//

        //������Ϣ����
        cms_8100::ReqB& r_req_msg = p_msg_wrap->GetMsg();
        r_req_msg.set_user_name(r_msg.user_name());

        std::cout<<"ServerB send ReqB, srcID "<<p_msg_wrap->GetWrapSrcId()<<" DstID "<<p_msg_wrap->GetWrapDstId()<<std::endl; 

        if (HPR_OK != ConnSession::SendMessage_r(p_msg_wrap, g_AHServiceConn->GetSessionId()))
        {
            std::cout << "SendMessage_r fail ..." <<std::endl;
            PBWrapFactory<cms_8100::ReqB>::DestroyPBWrap(p_msg_wrap);
        }
        else
        {
            std::cout << "SendMessage_r succ ..." <<std::endl;
        }
    }
    else
    {
        std::cout << "g_AHServiceConn is NULL ..." <<std::endl;
    }

    return NULL;
}

template<> inline WrapIf* PBWrap<cms_8100::RspB>::DoExecute()
{
    std::cout << "PBWrap<cms_8100::RspB>::DoExecute()" << std::endl;
    cms_8100::RspB & r_msg = GetMsg();
    std::cout<<r_msg.result().c_str()<<std::endl;

    std::cout<<"ServerB recv RspB, srcID "<<GetWrapSrcId()<<" DstID "<<GetWrapDstId()<<std::endl;
    
    //��ӦRspA
    PBWrap<cms_8100::RspA>* p_msg_wrap = PBWrapFactory<cms_8100::RspA>::CreatePBWrap();
    if (p_msg_wrap == NULL)
    {
        std::cout << "CreatePBWrap fail ..." <<std::endl;
        return NULL;
    }
    //����HPPЭ��ͷ
    p_msg_wrap->SetCommandId(CMD_RSP_A);
    p_msg_wrap->SetInnerSequence(GetInnerSequence()/*HPP_GetUnRepeatSeq()*/);
    p_msg_wrap->SetMessageType(HPP_PACK_HEAD::RSP_MSG_FINISH);//��Ҫ��Ӧ
    p_msg_wrap->SetWrapSrcId(GetWrapSrcId());//
    p_msg_wrap->SetWrapDstId(GetWrapDstId());//

    //������Ϣ����
    cms_8100::RspA& r_req_msg = p_msg_wrap->GetMsg();
    r_req_msg.set_result(r_msg.result());

    std::cout<<"ServerB send RspA, srcID "<<p_msg_wrap->GetWrapSrcId()<<" DstID "<<p_msg_wrap->GetWrapDstId()<<std::endl;

    if (HPR_OK != ConnSession::SendMessage_r(p_msg_wrap, GetWrapDstId()))
    {
        std::cout << "SendMessage_r fail ..." <<std::endl;
        PBWrapFactory<cms_8100::RspA>::DestroyPBWrap(p_msg_wrap);
    }
    else
    {
        std::cout << "SendMessage_r succ ..." <<std::endl;
    }


    return NULL;
}

HPR_BOOL _OnCheckTimeout_ServerB(ConnSession* pConnSession)
{
    std::cout<<"Info: OnCheckTimeout ..."<<std::endl;
    return HPR_FALSE;
}


HPR_INT32 _OnSocketClosed_ServerB(ConnSession* pConnSession)
{
    std::cout<<"_OnSocketClosed_ServerB ..."<<std::endl;
    return HPR_OK;
}


//���յ����ӵĻص�����
HPR_INT32 _OnAcceptClient_ServerB(ConnSession* pConnSession)
{
    std::cout<<"_OnAcceptClient_ServerB ..."<<std::endl;
    //���ûص�����������
    pConnSession->SetSocketClosedCallBack(_OnSocketClosed_ServerB);
    pConnSession->SetTimeOutCallBack(_OnCheckTimeout_ServerB);
    if(pConnSession->StartService(SERVICE_NORMAL_PRI) != HPR_OK)
    {
        std::cout<<"Error: StartService fail ..."<<std::endl;
        return HPR_ERROR;
    }

    std::cout <<"Accept Session ID " << pConnSession->GetSessionId()<<std::endl;

    return HPR_OK;
}
HPR_INT32 _OnConnectionClosed_Client(ConnSession* p_conn_session_)
{
    std::cout << "_OnConnectionClosed_Client" << std::endl;
    p_conn_session_->StopService();
    g_AHServiceConn = NULL;

    return 0;
}


HPR_INT32 _OnConnectionComplete_Client(ConnSession* p_conn_session_)
{
    std::cout << "_OnConnectionComplete_Client" << std::endl;

    p_conn_session_->SetSocketClosedCallBack(_OnConnectionClosed_Client);

    if (HPR_OK == p_conn_session_->StartService(SERVICE_NORMAL_PRI))
    {
        std::cout << "StartService succ ..." <<std::endl;
        g_AHServiceConn = p_conn_session_;
    }
    else
    {
        std::cout << "StartService fail ..." <<std::endl;
    }

    std::cout <<"Connect Session ID " << p_conn_session_->GetSessionId()<<std::endl;

    return HPR_OK;
}

HPR_INT32 _OnConnectionError_Client(HPR_VOIDPTR p_user_data_)
{
    std::cout << "_OnConnectionError_Client" << std::endl;

    return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
    std::cout<<"ServerB"<<std::endl;
    //��ʼ��HPP��,����(�����߳�,���������ĳ�ʱʱ��)
    HPP_HANDLE hHppHandle = HPP_Init(10, 30);  
    if (NULL == hHppHandle)
    {
        return HPR_ERROR;
    }

    CString strLocalIP;
    AppFun_GetLocalIPAddr(strLocalIP);

    //����HPP(Protocol BufferЭ��)�������ɻص�����,
    HPP_SetPbMsgCreateFun(hHppHandle,_CreateMessageByCmdId_ServerB);

    //�������ط���
    HPP_SERVER_HANDLE hSvrHandle = 	
        HPP_StartLocalServer				//��ʼ��һ������TCP��������
        (
        hHppHandle,						//HPP_Init ����ֵ
        CW2A(strLocalIP),					//���ذ󶨵�IP��ַ
        27520,							//���ؼ����Ķ˿�
        _OnAcceptClient_ServerB,					//���յ����ӵĻص�
        ConnSession::PROTOCOL_TYPE_HPP	//ʹ��HPPЭ��
        );	

    if(NULL == hSvrHandle)					//���ط��񴴽�ʧ��
    {
        HPP_Close(hHppHandle);
        std::cout<<"Error: HPP_StartLocalServer fail"<<std::endl;
        return HPR_ERROR;
    }

    //���ӽ��������
    int nConnectResult = HPP_ConnRemoteServiceNoBlock(hHppHandle
        , CW2A(strLocalIP), (HPR_UINT16)27020, _OnConnectionComplete_Client
        , NULL, 0, NULL, SERVICE_NORMAL_PRI, _OnConnectionError_Client);

    char c_input = 'a';
    while (c_input != 'x')
    {
        std::cout << "Press x to exit..." << std::endl;
        std::cin >> c_input;
    }

    HPP_StopLocalServer(hHppHandle, hSvrHandle);
    HPP_Close(hHppHandle);

    return 0;
}


