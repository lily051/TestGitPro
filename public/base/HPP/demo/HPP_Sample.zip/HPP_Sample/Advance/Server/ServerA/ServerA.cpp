// ServerA.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <hpp/hpp_hpp.h>
#include <string>
#include <iostream>

#include "../msg/ReqA.pb.h"
#include "../msg/RspA.pb.h"
#include "../msg/ReqB.pb.h"
#include "../msg/RspB.pb.h"

enum _cmd
{
    CMD_REQ_A       = 100,
    CMD_REQ_B       = 101,
    CMD_RSP_A       = 102,
    CMD_RSP_B       = 103,
};

//<�������Ľ�������
WrapIf* _CreateMessageByCmdId_Client(HPR_INT32 cmdId)
{
    std::cout << "_CreateMessageByCmdId_Client" << std::endl;

    WrapIf* p_wrap = NULL;	
    switch (cmdId)
    {
    case CMD_RSP_A:
        {
            p_wrap = PBWrapFactory<cms_8100::RspA>::CreatePBWrap();
        }
        break;
    default:
        p_wrap = NULL;
    }
    return p_wrap;
}
HPR_INT32 _OnConnectionClosed_Client(ConnSession* p_conn_session_)
{
    std::cout << "_OnConnectionClosed_Client" << std::endl;

    p_conn_session_->StopService();
    return 0;
}

HPR_INT32 _OnConnectionComplete_Client(ConnSession* p_conn_session_)
{
    std::cout << "_OnConnectionComplete_Client" << std::endl;

    p_conn_session_->SetSocketClosedCallBack(_OnConnectionClosed_Client);
    if (HPR_OK == p_conn_session_->StartService(SERVICE_NORMAL_PRI))
    {
        std::cout << "StartService succ ..." <<std::endl;
    }
    else
    {
        std::cout << "StartService fail ..." <<std::endl;
    }

    std::cout <<"Session ID " << p_conn_session_->GetSessionId()<<std::endl;

    PBWrap<cms_8100::ReqA>* p_msg_wrap = PBWrapFactory<cms_8100::ReqA>::CreatePBWrap();
    if (p_msg_wrap == NULL)
    {
        std::cout << "CreatePBWrap fail ..." <<std::endl;
        return HPR_ERROR;
    }
    //����HPPЭ��ͷ
    p_msg_wrap->SetCommandId(CMD_REQ_A);
    p_msg_wrap->SetInnerSequence(HPP_GetUnRepeatSeq());
    p_msg_wrap->SetMessageType(HPP_PACK_HEAD::REQ_MSG_NEED_RSP);//��Ҫ��Ӧ
    p_msg_wrap->SetWrapDstId(p_conn_session_->GetSessionId());

    //������Ϣ����
    cms_8100::ReqA& r_req_msg = p_msg_wrap->GetMsg();
    r_req_msg.set_user_name("liangjungao");

    std::cout<<"ServerA send, srcID "<<p_msg_wrap->GetWrapSrcId()<<" DstID "<<p_msg_wrap->GetWrapDstId()<<std::endl; 

    if (HPR_OK != ConnSession::SendMessage_r(p_msg_wrap, p_conn_session_->GetSessionId()))
    {
        std::cout << "SendMessage_r fail ..." <<std::endl;
        PBWrapFactory<cms_8100::ReqA>::DestroyPBWrap(p_msg_wrap);
        return HPR_ERROR;
    }
    else
    {
        std::cout << "SendMessage_r succ ..." <<std::endl;
        return HPR_OK;
    }
    return 0;
}

HPR_INT32 _OnConnectionError_Client(HPR_VOIDPTR p_user_data_)
{
    std::cout << "_OnConnectionError_Client" << std::endl;

    return 0;
}

template<> inline HPR_INT32 PBWrap<cms_8100::ReqA>::DoTimeout()
{
    std::cout << "PBWrap<cms_8100::ReqA>::DoTimeout()" << std::endl;

    return HPR_OK;
}

template<> inline WrapIf* PBWrap<cms_8100::RspA>::DoExecute()
{
    std::cout << "PBWrap<cms_8100::RspA>::DoExecute()" << std::endl;

    cms_8100::RspA & r_msg = GetMsg();

    std::cout << r_msg.result().c_str() << std::endl;

    return NULL;
}


int _tmain(int argc, _TCHAR* argv[])
{
    std::cout<<"ServerA"<<std::endl;
    //��ʼ��HPP��,����(�����߳�,���������ĳ�ʱʱ��)
    HPP_HANDLE hHppHandle = HPP_Init(10, 30);  
    if (NULL == hHppHandle)
    {
        return HPR_ERROR;
    }

    CString strLocalIP;
    AppFun_GetLocalIPAddr(strLocalIP);

    //����HPP(Protocol BufferЭ��)�������ɻص�����,
    HPP_SetPbMsgCreateFun(hHppHandle,_CreateMessageByCmdId_Client);

    //�������������
    int nConnectResult = HPP_ConnRemoteServiceNoBlock(hHppHandle
        , CW2A(strLocalIP), (HPR_UINT16)27520, _OnConnectionComplete_Client
        , NULL, 0, NULL, SERVICE_NORMAL_PRI, _OnConnectionError_Client);

    char c_input = 'a';
    while (c_input != 'x')
    {
        std::cout << "Press x to exit..." << std::endl;
        std::cin >> c_input;
    }

    HPP_Close(hHppHandle);

    return 0;
}

