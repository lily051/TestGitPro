// Sample_2_1.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <time.h>

#include <hpp/hpp_hpp.h>//<HPPЭ��ջ��ͷ�ļ�

//pbͷ�ļ�
#include "../pb/cmd.pb.h"
#include "../pb/DevEventInfo.pb.h"

BOOL g_bShouldStop = TRUE;
ConnSession* g_pConnSeesion = NULL;//�����ϵ�Session

//////////////////////////////////////////////////////////////////////////
WrapIf* CreateMessageByCmdId_Client(HPR_INT32 cmdId)
{
	std::cout<<"Info: CreateMessageByCmdId_Client ..."<<std::endl;
	WrapIf* p_wrap = NULL;
	return p_wrap;
}
//////////////////////////////////////////////////////////////////////////
template<> inline HPR_INT32 PBWrap<event_8100::DevEventInfo>::DoTimeout()
{
	std::cout << "Info: PBWrap<event_8100::DevEventInfo>::DoTimeout()..." << std::endl;

	return HPR_OK;
}



//////////////////////////////////////////////////////////////////////////
HPR_INT32 OnConnectionClosed_Client(ConnSession* p_conn_session_)
{
	std::cout<<"Info: OnConnectionClosed_Client"<<std::endl;

	if (g_pConnSeesion != NULL && g_pConnSeesion==p_conn_session_)
	{
		g_pConnSeesion->StopService();
		g_pConnSeesion = NULL;
	}
	
	return HPR_OK;
}

//////////////////////////////////////////////////////////////////////////
HPR_INT32 OnConnectionError_Client(HPR_VOIDPTR p_user_data_)
{
	std::cout<<"Info: OnConnectionError_Client"<<std::endl;
	return 0;
}

//////////////////////////////////////////////////////////////////////////
HPR_BOOL OnCheckTimeout_Client(ConnSession* pConnSession)
{
	std::cout<<"Info: OnCheckTimeout"<<std::endl;
	return HPR_TRUE;
}

//////////////////////////////////////////////////////////////////////////
HPR_INT32 OnConnectionComplete_Client(ConnSession* p_conn_session_)
{
	std::cout<<"Info: OnConnectionComplete_Client ..."<<std::endl;
	//���ûص�����������
	p_conn_session_->SetSocketClosedCallBack(OnConnectionClosed_Client);
	p_conn_session_->SetTimeOutCallBack(OnCheckTimeout_Client);
	if (HPR_OK != p_conn_session_->StartService(SERVICE_NORMAL_PRI))
	{
		std::cout<<"Error: StartService fail ..."<<std::endl;
		return HPR_ERROR;
	}

	g_pConnSeesion = p_conn_session_;

	return HPR_OK;
}

HPR_VOIDPTR CALLBACK DevEventThreadFun(HPR_VOIDPTR p_user_data_)
{
	while(!g_bShouldStop)
	{
		if (g_pConnSeesion == NULL)
		{
			HPR_Sleep(200);
			continue;
		}
		PBWrap<event_8100::DevEventInfo>* p_req_wrap = 
			PBWrapFactory<event_8100::DevEventInfo>::CreatePBWrap();
		if (p_req_wrap == NULL)
		{
			std::cout<<"Error: CreatePBWrap fail ..."<<std::endl;
			return HPR_FALSE;
		}

		//����Э��ͷ
		p_req_wrap->SetCommandId(event_8100::CMD_DEV_EVENT_INFO);
		p_req_wrap->SetInnerSequence(HPP_GetUnRepeatSeq());
		p_req_wrap->SetMessageType(HPP_PACK_HEAD::REQ_MSG_NOT_NEED_RSP);
		p_req_wrap->SetWrapDstId(g_pConnSeesion->GetSessionId());
		//��������
		event_8100::DevEventInfo& r_req_msg = p_req_wrap->GetMsg();
		r_req_msg.set_cmd(event_8100::CMD_DEV_EVENT_INFO);
		r_req_msg.set_type(time(NULL)%20);
		r_req_msg.set_sub_type(time(NULL)%16);
		r_req_msg.set_dev_ip("172.7.15.201");
		r_req_msg.set_dev_port(8000);
		r_req_msg.set_dev_sn("HIK-8100");
		r_req_msg.set_info("Alarm....");
		r_req_msg.set_append_info("Tel:8280;Name:liangjungao");
		r_req_msg.set_status(1);
		r_req_msg.set_occur_time("2012-03-16 ........");
		r_req_msg.set_cur_guid("6F9619FF-8B86-D011-B42D-00C04FC964FF");

		if (HPR_OK != ConnSession::SendMessage_r(p_req_wrap, g_pConnSeesion->GetSessionId()))
		{
			PBWrapFactory<event_8100::DevEventInfo>::DestroyPBWrap(p_req_wrap);
			std::cout<<"Error: DestroyPBWrap fail ..."<<std::endl;
		}
		HPR_Sleep(1000);
	}
	return NULL;
}


//////////////////////////////////////////////////////////////////////////
int _tmain(int argc, _TCHAR* argv[])
{
	//��ʼ��HPP��,ʹ�����������߳�,���ñ��������ĳ�ʱʱ��Ϊ��
	HPP_HANDLE hHandle = HPP_Init(2, 10);  	
	if(NULL == hHandle)
	{
		return HPR_ERROR;
	}

	//����HPP(Protocol BufferЭ��)�������ɻص�����,
	HPP_SetPbMsgCreateFun(hHandle,CreateMessageByCmdId_Client);	

	CString strLocalIP;
	AppFun_GetLocalIPAddr(strLocalIP);

	//����ģʽ����
	HPR_INT32 hResult = HPP_ConnRemoteService(hHandle,CW2A(strLocalIP), 
		6600,OnConnectionComplete_Client,
		NULL, 0, ConnSession::PROTOCOL_TYPE_HPP,NULL, SERVICE_NORMAL_PRI);

	if (HPR_OK != hResult)
	{
		std::cout<<"Error: ����ʧ�� ..."<<std::endl;
	}

	////��������
	//HPR_INT32 n_ret = HPP_ConnRemoteServiceNoBlock(hHandle, CW2A(strLocalIP), 6600, 
	//OnConnectionComplete_Client, NULL, 0, NULL, SERVICE_NORMAL_PRI, OnConnectionError_Client);

	g_bShouldStop = FALSE;
	HPR_Thread_Create(DevEventThreadFun, 0, 0);

	char c_input = 'a';
	while (c_input != 'x' && c_input != 'X')
	{
		std::cout << "Press x to exit..." << std::endl;
		std::cin >> c_input;
	}

	g_bShouldStop = TRUE;

	HPP_Close(hHandle);

	return HPR_OK;
}


