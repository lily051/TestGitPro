// Sample_1_1.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include <hpp/hpp_hpp.h>//<HPPЭ��ջ��ͷ�ļ�

//pbͷ�ļ�
#include "../pb/cmd.pb.h"
#include "../pb/ClientLoginReq.pb.h"
#include "../pb/ClientLoginRsp.pb.h"


//////////////////////////////////////////////////////////////////////////
WrapIf* CreateMessageByCmdId_Client(HPR_INT32 cmdId)
{
	std::cout<<"Info: CreateMessageByCmdId_Client ..."<<std::endl;
	WrapIf* p_wrap = NULL;
	switch (cmdId)
	{
	case event_8100::CMD_CLIENT_LOGIN_RSP://Client
		{
			p_wrap = PBWrapFactory<event_8100::ClientLoginRsp>::CreatePBWrap();
		}
		break;
	default:
		p_wrap = NULL;
	}

	return p_wrap;
}
//////////////////////////////////////////////////////////////////////////
template<> inline HPR_INT32 PBWrap<event_8100::ClientLoginReq>::DoTimeout()
{
	std::cout << "Info: PBWrap<event_8100::ClientLoginReq>::DoTimeout()..." << std::endl;

	return HPR_OK;
}

template<> inline WrapIf* PBWrap<event_8100::ClientLoginRsp>::DoExecute()
{
	std::cout << "Info: PBWrap<event_8100::ClientLoginRsp>::DoExecute()..." << std::endl;

	event_8100::ClientLoginRsp& r_msg = GetMsg();

	HPP_PACK_HEAD head = GetPackHead();
	if (head.m_nMark == HPP_PACK_HEAD::RSP_MSG_NOT_FINISH)
	{
		event_8100::CMD cmd = r_msg.cmd();
		int result = r_msg.result();
		std::string  result_info = r_msg.result_info();
		std::cout<<"Info: *[cmd]"<<cmd<<" [result]"<<result<<" [result_info]" << result_info << std::endl;
	}
	else if (head.RSP_MSG_FINISH)
	{
		event_8100::CMD cmd = r_msg.cmd();
		int result = r_msg.result();
		std::string  result_info = r_msg.result_info();
		std::cout<<"Info: [cmd]"<<cmd<<" [result]"<<result<<" [result_info]" << result_info << std::endl;
	}

	return NULL;
}


//////////////////////////////////////////////////////////////////////////
HPR_INT32 OnConnectionClosed_Client(ConnSession* p_conn_session_)
{
	std::cout<<"Info: OnConnectionClosed_Client"<<std::endl;
	return HPR_OK;
}

//////////////////////////////////////////////////////////////////////////
HPR_INT32 OnConnectionError_Client(HPR_VOIDPTR p_user_data_)
{
	std::cout<<"Info: OnConnectionError_Client"<<std::endl;
	return 0;
}

//////////////////////////////////////////////////////////////////////////
HPR_BOOL OnCheckTimeout_Client(ConnSession* pConnSession)
{
	std::cout<<"Info: OnCheckTimeout"<<std::endl;
	return HPR_TRUE;
}

//////////////////////////////////////////////////////////////////////////
HPR_INT32 OnConnectionComplete_Client(ConnSession* p_conn_session_)
{
	std::cout<<"Info: OnConnectionComplete_Client ..."<<std::endl;
	//���ûص�����������
	p_conn_session_->SetSocketClosedCallBack(OnConnectionClosed_Client);
	p_conn_session_->SetTimeOutCallBack(OnCheckTimeout_Client);
	if (HPR_OK != p_conn_session_->StartService(SERVICE_NORMAL_PRI))
	{
		std::cout<<"Error: StartService fail ..."<<std::endl;
		return HPR_ERROR;
	}

	//����һ����¼����
	PBWrap<event_8100::ClientLoginReq>* p_req_wrap = 
		PBWrapFactory<event_8100::ClientLoginReq>::CreatePBWrap();
	if (p_req_wrap == NULL)
	{
		std::cout<<"Error: CreatePBWrap fail ..."<<std::endl;
		return HPR_FALSE;
	}

	p_req_wrap->SetCommandId(event_8100::CMD_CLIENT_LOGIN_REQ);
	p_req_wrap->SetInnerSequence(HPP_GetUnRepeatSeq());
	p_req_wrap->SetMessageType(HPP_PACK_HEAD::REQ_MSG_NEED_RSP);//��Ҫ��Ӧ
	p_req_wrap->SetWrapDstId(p_conn_session_->GetSessionId());

	event_8100::ClientLoginReq& r_req_msg = p_req_wrap->GetMsg();
	r_req_msg.set_cmd(event_8100::CMD_CLIENT_LOGIN_REQ);
	r_req_msg.set_user_name("liangjungao");
	r_req_msg.set_user_pwd("99999");

	if (HPR_OK != ConnSession::SendMessage_r(p_req_wrap, p_conn_session_->GetSessionId()))
	{
		std::cout<<"Error: SendMessage_r fail ..."<<std::endl;
		PBWrapFactory<event_8100::ClientLoginReq>::DestroyPBWrap(p_req_wrap);
	}
	else
	{
		std::cout<<"Info: SendMessage_r succ ..."<<std::endl;
	}

	return HPR_OK;
}

//////////////////////////////////////////////////////////////////////////
int _tmain(int argc, _TCHAR* argv[])
{
	//��ʼ��HPP��,ʹ�����������߳�,���ñ��������ĳ�ʱʱ��Ϊ��
	HPP_HANDLE hHandle = HPP_Init(2, 10);  	
	if(NULL == hHandle)
	{
		return HPR_ERROR;
	}

	//����HPP(Protocol BufferЭ��)�������ɻص�����,
	HPP_SetPbMsgCreateFun(hHandle,CreateMessageByCmdId_Client);	

	CString strLocalIP;
	AppFun_GetLocalIPAddr(strLocalIP);

	//����ģʽ����
	HPR_INT32 hResult = HPP_ConnRemoteService(hHandle,CW2A(strLocalIP), 
		6620,OnConnectionComplete_Client,
		NULL, 0, ConnSession::PROTOCOL_TYPE_HPP,NULL, SERVICE_NORMAL_PRI);

	if (HPR_OK != hResult)
	{
		std::cout<<"Error: ����ʧ�� ..."<<std::endl;
	}

	////��������
	//HPR_INT32 n_ret = HPP_ConnRemoteServiceNoBlock(hHandle, CW2A(strLocalIP), 6620, 
	//OnConnectionComplete_Client, NULL, 0, NULL, SERVICE_NORMAL_PRI, OnConnectionError_Client);

	char c_input = 'a';
	while (c_input != 'x' && c_input != 'X')
	{
		std::cout << "Press x to exit..." << std::endl;
		std::cin >> c_input;
	}

	HPP_Close(hHandle);

	return HPR_OK;
}

