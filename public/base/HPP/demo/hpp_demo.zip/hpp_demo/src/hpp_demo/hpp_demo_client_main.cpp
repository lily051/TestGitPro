/** @file   hpp_demo_client_main.cpp
 *  @note   HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 *  @brief  
 *          
 *  @author fangyu@hikvision.com
 *  @date   2012/2/28
 */

#include <conio.h>
#include <iostream>
#include "hpp_demo_client.h"
#include "demo_client_logic.h"


/** @fn     WrapIf* CreateMessageByCmdId(HPR_INT32 n_cmd_id)
 *  @brief  Create PBWrap Callback function
 *  @param  n_cmd_id [in] command id
 *  @return Pointer to PBWrap instance or NULL
 *  @throws void
 */
WrapIf* CreateMessageByCmdId(HPR_INT32 n_cmd_id)
{
    WrapIf* p_wrap = NULL;

    switch (n_cmd_id)
    {
    case hpp_demo::DEMO_AUTHORIZE_RSP:
        p_wrap = PBWrapFactory<hpp_demo::DemoAuthorizeRsp>::CreatePBWrap();
        break;
    case hpp_demo::DEMO_CHECK_PRIME_REQ:
        p_wrap = PBWrapFactory<hpp_demo::DemoCheckPrimeReq>::CreatePBWrap();
        break;
    default:
        p_wrap = NULL;
    }

    return p_wrap;
}

#ifdef _WIN32
static HPR_INT32 InitWorkPath()
{
    char path[256] = {0};
    GetModuleFileNameA(NULL, path, 256);
    for (int i = (int)strlen(path); i >= 0; --i)
    {
        if (path[i] == '\\')
        {
            path[i]=0;
            break;
        }
    }
    SetCurrentDirectoryA((LPCSTR)path);
    return HPR_OK;	
}
#endif

int main(int argc, char* argv[])
{
    if (argc != 5)
    {
        std::cout << "Please input parameters like:" << std::endl;
        std::cout << "name password server_ip server_port" << std::endl;
        std::cout << "Press any key to continue..." << std::endl;
        _getch();
        return 0;
    }

    std::string name = argv[1];
    std::string password = argv[2];
    std::string server_ip = argv[3];
    HPR_UINT16  server_port = (HPR_UINT16)atoi(argv[4]);

#ifdef _WIN32
    InitWorkPath();
#endif

    ///< Initialize log system
    hlog_init("log4cxx.properties");

    ///< Initialize Demo client singleton
    CHPPDemoClient::Instance();

    do 
    {
        ///< Initialize HPP
        HPP_HANDLE h_hpp = HPP_Init(2, 30, HPR_FALSE);
        if (h_hpp == NULL)
        {
            LOG_ERROR("HPP init failed");
            break;
        }

        std::cout << "HPP " << HPP_GetVersion() << std::endl;

        ///< Set PB Wrap create callback function
        HPP_SetPbMsgCreateFun(h_hpp, CreateMessageByCmdId);

        ///< Initialize and start Demo client 
        CHPPDemoClient::Instance()->Init(h_hpp, name, password, server_ip, server_port);
        CHPPDemoClient::Instance()->StartUp();

        ///< wait for 'x' to exit logic
        char c_input = 'a';
        while (c_input != 'x' && c_input != 'X')
        {
            std::cout << "Press x to exit..." << std::endl;
            std::cin >> c_input;
        }

        ///< ShutDown and finalize Demo client
        CHPPDemoClient::Instance()->ShutDown();
        CHPPDemoClient::Instance()->Finalize();

        ///< Close HPP
        HPP_Close(h_hpp);

    } while (0);

    ///< Destroy Demo client singleton
    CHPPDemoClient::Free();

    google::protobuf::ShutdownProtobufLibrary();

    ///< Finalize log system
    hlog_fini();

    return 0;
}
