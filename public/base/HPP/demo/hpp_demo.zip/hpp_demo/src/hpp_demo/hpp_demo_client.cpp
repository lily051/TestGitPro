/** @file   hpp_demo_client.cpp
 *  @note   HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 *  @brief  
 *          
 *  @author fangyu@hikvision.com
 *  @date   2012/2/27
 */

#include "hpp_demo_client.h"
#include "demo_client_logic.h"


CHPPDemoClient* CHPPDemoClient::m_instance = NULL;

/** @fn     CHPPDemoClient::CHPPDemoClient()
 *  @brief  Constructor
 *  @param  void
 *  @return void
 */
CHPPDemoClient::CHPPDemoClient()
: m_h_hpp(NULL)
, m_s_name("")
, m_s_password("")
, m_s_server_ip("")
, m_n_server_port(0)
, m_n_server_session_id(0)
, m_p_server_session(NULL)
{
}

/** @fn     CHPPDemoClient::~CHPPDemoClient()
 *  @brief  Destructor
 *  @param  void
 *  @return void
 */
CHPPDemoClient::~CHPPDemoClient()
{
    m_h_hpp = NULL;
    m_p_server_session = NULL;
}

/** @fn     HPR_INT32 CHPPDemoClient::Instance()
 *  @brief  Get HPP demo client instance
 *  @param  void
 *  @return HPP demo client instance
 */
CHPPDemoClient* CHPPDemoClient::Instance()
{
    if (m_instance == NULL)
    {
        m_instance = new (std::nothrow) CHPPDemoClient();
    }
    return m_instance;
}

/** @fn     HPR_VOID CHPPDemoClient::Free()
 *  @brief  Destroy HPP demo client instance
 *  @param  void
 *  @return void
 */
HPR_VOID CHPPDemoClient::Free()
{
    if (m_instance != NULL)
    {
        delete m_instance;
        m_instance = NULL;
    }
}

/** @fn     HPR_INT32 CHPPDemoClient::Init(HPP_HANDLE h_hpp_, const std::string& s_name_, const std::string& s_password_, const std::string& s_server_ip_, HPR_UINT16 n_server_port_)
 *  @brief  Initialize HPP demo client
 *  @param  h_hpp_ [in] HPP handle
 *  @param  s_name_ [in] client name
 *  @param  s_password_ [in] access password
 *  @param  s_server_ip_ [in] HPP demo server ip
 *  @param  n_server_port_ [in] HPP demo server port
 *  @return success, HPR_OK; else, HPR_ERROR
 */
HPR_INT32 CHPPDemoClient::Init(HPP_HANDLE h_hpp_, const std::string& s_name_, const std::string& s_password_, const std::string& s_server_ip_, HPR_UINT16 n_server_port_)
{
    if (h_hpp_ == NULL || s_name_ == "" || s_password_ == "" || s_server_ip_ == "" || n_server_port_ == 0)
    {
        LOG_ERROR("Invalid Parameters found");
        return HPR_ERROR;
    }

    m_h_hpp = h_hpp_;
    m_s_name = s_name_;
    m_s_password = s_password_;
    m_s_server_ip = s_server_ip_;
    m_n_server_port = n_server_port_;

    return HPR_OK;
}

/** @fn     HPR_INT32 CHPPDemoClient::Finalize()
 *  @brief  Finalize
 *  @param  void
 *  @return HPR_OK
 */
HPR_INT32 CHPPDemoClient::Finalize()
{
    m_h_hpp = NULL;
    m_s_name = "";
    m_s_password = "";
    m_s_server_ip = "";
    m_n_server_port = 0;

    return HPR_OK;
}

/** @fn     HPR_INT32 CHPPDemoClient::StartUp()
 *  @brief  StartUp HPP demo client
 *  @param  void
 *  @return success, HPR_OK; else, HPR_ERROR
 */
HPR_INT32 CHPPDemoClient::StartUp()
{
    ///< Use asynchronous connect api to connect to server
    HPR_INT32 n_ret = HPP_ConnRemoteServiceNoBlock(
        m_h_hpp, m_s_server_ip.c_str(), m_n_server_port, 
        OnConnectionComplete, NULL, 0, NULL, SERVICE_NORMAL_PRI, OnConnectionError);

    if (n_ret == HPR_ERROR)
    {
        LOG_ERROR("Connect to HPP demo server(%s:%d) failed",
            m_s_server_ip.c_str(), m_n_server_port);
        return HPR_ERROR;
    }
    return HPR_OK;
}

/** @fn     HPR_INT32 CHPPDemoClient::ShutDown()
 *  @brief  ShutDown HPP demo client
 *  @param  void
 *  @return HPR_OK
 */
HPR_INT32 CHPPDemoClient::ShutDown()
{
    if (m_p_server_session != NULL)
    {
        ///< Stop ConnSession
        m_p_server_session->StopService();
        m_p_server_session = NULL;
        m_n_server_session_id = 0;
    }
    return HPR_OK;
}

/** @fn     HPR_INT32 CHPPDemoClient::OnConnectionClosed(ConnSession* p_conn_session_)
 *  @brief  Callback function when HPP connect session has been closed
 *  @param  p_conn_session_ [in] the session has been closed
 *  @return HPR_OK
 */
HPR_INT32 CHPPDemoClient::OnConnectionClosed(ConnSession* p_conn_session_)
{
    if (p_conn_session_ != NULL)
    {
        if (p_conn_session_->GetSessionId() ==
            CHPPDemoClient::Instance()->ServerSessionId())
        {
            LOG_ERROR("Session to HPP demo server has been closed");
        }
        else
        {
            LOG_ERROR("Unknow session closed");
        }
    }

    return HPR_OK;
}

/** @fn     HPR_INT32 CHPPDemoClient::OnConnectionComplete(ConnSession* p_conn_session_)
 *  @brief  Callback function when HPP connect complete
 *  @param  p_conn_session_ [in] the session has been complete
 *  @return success HPR_OK; else, HPR_ERROR
 */
HPR_INT32 CHPPDemoClient::OnConnectionComplete(ConnSession* p_conn_session_)
{
    p_conn_session_->SetSocketClosedCallBack(OnConnectionClosed);
    p_conn_session_->SetServiceType(0x3738);    ///< client to server, 55 to 56

    ///< start ConnSession
    if (HPR_OK != p_conn_session_->StartService(SERVICE_NORMAL_PRI))
    {
        LOG_ERROR("Start session error");
        return HPR_ERROR;
    }

    CHPPDemoClient::Instance()->ServerSessionId(p_conn_session_->GetSessionId());
    CHPPDemoClient::Instance()->ServerSession(p_conn_session_);

    ///< from and send authorization wrap to server
    WrapIf* p_wrap = CHPPDemoClient::Instance()->FormAuthorizationWrap();
    if (NULL != p_wrap)
    {
        LOG_SEND_WRAP(p_wrap);
        int n_ret = p_conn_session_->SendMessage(p_wrap);
        if (HPR_OK != n_ret)
        {
            PBWrapFactory<hpp_demo::DemoAuthorizeReq>::DestroyPBWrap(p_wrap);
            HPP_ERROR("HPP demo client send authorization wrap failed");
        }

        return n_ret;
    }
    else
    {
        return HPR_ERROR;
    }
}

/** @fn     HPR_INT32 CHPPDemoClient::OnConnectionError(HPR_VOIDPTR p_user_data_)
 *  @brief  Callback function when HPP connect failed
 *  @param  
 *  @return 
 */
HPR_INT32 CHPPDemoClient::OnConnectionError(HPR_VOIDPTR p_user_data_)
{
    HPP_ERROR("HPP demo client connect to server failed");
    return HPR_OK;
}

/** @fn     WrapIf* CHPPDemoClient::FormAuthorizationWrap()
 *  @brief  From a Authorization wrap
 *  @param  void
 *  @return success, pointer to Authorization wrap; else, NULL
 */
WrapIf* CHPPDemoClient::FormAuthorizationWrap()
{
    PBWrap<hpp_demo::DemoAuthorizeReq>* p_wrap =
        PBWrapFactory<hpp_demo::DemoAuthorizeReq>::CreatePBWrap();
    if (NULL == p_wrap)
    {
        LOG_ERROR("Create DemoAuthorizeReq wrap failed, no memory");
        return NULL;
    }

    hpp_demo::DemoAuthorizeReq& r_msg = p_wrap->GetMsg();
    hpp_demo::Cmd* p_cmd = r_msg.mutable_cmd();

    ///< Set wrap head
    p_wrap->SetCommandId(hpp_demo::DEMO_AUTHORIZE_REQ);
    p_wrap->SetInnerSequence(HPP_GetUnRepeatSeq());
    p_wrap->SetMessageType(HPP_PACK_HEAD::REQ_MSG_NEED_RSP);
    p_wrap->SetWrapDstId(m_n_server_session_id);

    ///< Set wrap body
    r_msg.set_client_name(m_s_name);
    r_msg.set_password(m_s_password);
    r_msg.set_server_type(hpp_demo::DEMO_CLIENT);
    
    ///< Set wrap body info
    p_cmd->set_cmd_id(hpp_demo::DEMO_AUTHORIZE_REQ);
    p_cmd->set_cmd_string("DemoAuthorizeReq");
    
    return p_wrap;
}

/** @fn     HPR_INT32 CHPPDemoClient::CheckPrime(HPR_INT32 n_number_needs_check_)
 *  @brief  Check if input number is a prime number
 *  @param  n_number_needs_check_ [in] number needs check
 *  @return is prime number, HPR_TRUE; else, HPR_FALSE
 */
HPR_BOOL CHPPDemoClient::CheckPrime(HPR_INT32 n_number_needs_check_)
{
    if (1 >= n_number_needs_check_)
    {
        return HPR_FALSE;
    }

    if (0 == n_number_needs_check_ % 2)
    {
        return n_number_needs_check_ == 2 ? HPR_TRUE : HPR_FALSE;
    }

    for (int i = 3; ; i += 2)
    {
        if (i > n_number_needs_check_ / i)
        {
            break;
        }

        if (n_number_needs_check_ % i == 0)
        {
            return HPR_FALSE;
        }
    }

    return HPR_TRUE;
}
