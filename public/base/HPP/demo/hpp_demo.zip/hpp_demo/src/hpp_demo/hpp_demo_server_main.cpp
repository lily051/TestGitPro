/** @file   hpp_demo_server_main.cpp
 *  @note   HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 *  @brief  
 *          
 *  @author fangyu@hikvision.com
 *  @date   2012/2/28
 */

#include <conio.h>
#include <iostream>

#include "demo_server_logic.h"
#include "hpp_demo_server.h"


WrapIf* CreateMessageByCmdId(HPR_INT32 n_cmd_id)
{
    WrapIf* p_wrap = NULL;

    switch (n_cmd_id)
    {
    case hpp_demo::DEMO_AUTHORIZE_REQ:
        p_wrap = PBWrapFactory<hpp_demo::DemoAuthorizeReq>::CreatePBWrap();
        break;
    case hpp_demo::DEMO_CHECK_PRIME_RSP:
        p_wrap = PBWrapFactory<hpp_demo::DemoCheckPrimeRsp>::CreatePBWrap();
        break;
    default:
        p_wrap = NULL;
    }

    return p_wrap;
}

#ifdef _WIN32
static HPR_INT32 InitWorkPath()
{
    char path[256] = {0};
    GetModuleFileNameA(NULL, path, 256);
    for (int i = (int)strlen(path); i >= 0; --i)
    {
        if (path[i] == '\\')
        {
            path[i]=0;
            break;
        }
    }
    SetCurrentDirectoryA((LPCSTR)path);
    return HPR_OK;	
}
#endif

int main(int argc, char* argv[])
{
    if (argc != 5)
    {
        std::cout << "Please input parameters like:" << std::endl;
        std::cout << "server_ip server_port password test_number" << std::endl;
        std::cout << "Press any key to continue..." << std::endl;
        _getch();
        return 0;
    }

    std::string local_ip = argv[1];
    HPR_UINT16  local_port = (HPR_UINT16)atoi(argv[2]);
    std::string password = argv[3];
    HPR_INT32 test_number = (HPR_INT32)atoi(argv[4]);

#ifdef _WIN32
    InitWorkPath();
#endif

    ///< Initialize log system
    hlog_init("log4cxx.properties");

    ///< Initialize Demo server singleton
    CHPPDemoServer::Instance();

    do 
    {
        ///< Initialize HPP
        HPP_HANDLE h_hpp = HPP_Init(4, 30, HPR_FALSE);
        if (h_hpp == NULL)
        {
            LOG_ERROR("HPP init failed");
            break;
        }

        ///< Set PB Wrap create callback function
        HPP_SetPbMsgCreateFun(h_hpp, CreateMessageByCmdId);

        ///< Initialize and start Demo server
        CHPPDemoServer::Instance()->Init(h_hpp, local_ip, local_port, password, test_number);
        CHPPDemoServer::Instance()->StartUp();

        ///< wait for 'x' to exit logic
        char c_input = 'a';
        while (c_input != 'x' && c_input != 'X')
        {
            std::cout << "Press x to exit..." << std::endl;
            std::cin >> c_input;
        }

        ///< Shutdown and Finalize Demo server
        CHPPDemoServer::Instance()->ShutDown();
        CHPPDemoServer::Instance()->Finalize();

        ///< Close HPP
        HPP_Close(h_hpp);

    } while (0);

    ///< Destroy Demo server singleton
    CHPPDemoServer::Free();

    google::protobuf::ShutdownProtobufLibrary();

    ///< Finalize log system
    hlog_fini();

    return 0;
}
