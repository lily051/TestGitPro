/** @file   hpp_demo_server.h
 *  @note   HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 *  @brief  
 *          
 *  @author fangyu@hikvision.com
 *  @date   2012/2/27
 */

#ifndef __HPP_DEMO_SERVER_H__
#define __HPP_DEMO_SERVER_H__

#include <string>
#include <map>
#include <vector>
#include <hpp/hpp_hpp.h>
#include <hpr/HPR_Thread.h>
#include <hpr/HPR_Guard.h>
#include <hpr/HPR_Atomic.h>
#include <hlog/hlog.h>

/**< HPP demo server configuration */
const std::string   g_s_local_ip    = "172.7.28.55";
const HPR_UINT16    g_n_local_port  = 7860;
const std::string   g_s_password    = "88075998";

const HPR_INT32     PERFORMANCE_TEST_NUM    = 10000000;

// #ifndef PERFORMANCE_TEST_SWITCH_ON
// #define PERFORMANCE_TEST_SWITCH_ON
// #endif
/**< HPP demo server configuration end */

#define LOG_RECV_WRAP \
{\
    std::string s_recv_message;\
    PrintToString(&s_recv_message);\
    HPP_TRACE("Recv Message: %s", s_recv_message.c_str());\
}

#define LOG_SEND_WRAP(p_wrap) \
{\
    std::string s_send_message;\
    p_wrap->GetContentLen();\
    p_wrap->PrintToString(&s_send_message);\
    HPP_TRACE("Send Message: %s", s_send_message.c_str());\
}

class CHPPDemoServer
{
public:
    CHPPDemoServer();
    ~CHPPDemoServer();

    static CHPPDemoServer* Instance();
    static void Free();

    HPR_INT32 Init(HPP_HANDLE h_hpp_, const std::string& s_local_ip_, HPR_UINT16 n_local_port_, const std::string& s_password_, HPR_INT32 n_test_number_ = 100000);
    HPR_INT32 Finalize();
    HPR_INT32 StartUp();
    HPR_INT32 ShutDown();

    static HPR_INT32 OnAcceptClient(ConnSession* p_conn_session_);
    static HPR_INT32 OnSocketClosed(ConnSession* p_conn_session_);

    static HPR_VOIDPTR CALLBACK CheckPrimeRequester(HPR_VOIDPTR p_user_data_);
    HPR_VOID CheckPrimeRequesterThread();

    static HPR_VOIDPTR CALLBACK PerformanceTest(HPR_VOIDPTR p_user_data_);
    HPR_VOID PerformanceTestThread();
    static void IncRecvNumber();

    HPR_BOOL Authorize(const std::string& s_password_);
    HPR_INT32 AddSessionId(HPR_INT32 n_session_id_, const std::string& s_name_ = "");
    HPR_INT32 RemoveSessionId(HPR_INT32 n_session_id_);

private:

    HPP_HANDLE m_h_hpp;
    std::string m_s_local_ip;
    HPR_UINT16 m_n_local_port;
    std::string m_s_password;
    HPP_SERVER_HANDLE m_h_server;

    HPR_BOOL m_b_should_stop;
    HPR_HANDLE m_h_requester_thread;

    HPR_INT32 m_n_test_number;
    static HPR_ATOMIC_T m_n_performance_recv_number;   ///< active in performance test

    HPR_Mutex m_client_map_mutex;
    typedef std::vector<HPR_INT32 /*session id*/> tmp_session_list;
    tmp_session_list m_tmp_session_list;
    typedef std::map<HPR_INT32/* session_id*/, std::string/*client name*/> clients;
    clients m_clients;

    static CHPPDemoServer* m_instance;
};

#endif // __HPP_DEMO_SERVER_H__
