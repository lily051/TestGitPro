/** @file   demo_client_logic.h
 *  @note   HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 *  @brief  
 *          
 *  @author fangyu@hikvision.com
 *  @date   2012/2/27
 */

#ifndef __DEMO_CLIENT_LOGIC_H__
#define __DEMO_CLIENT_LOGIC_H__

#include <string>
#include <map>
#include <hpp/hpp_hpp.h>
#include <hpr/HPR_Types.h>
#include <hpr/HPR_Time.h>
#include "hpp_demo_client.h"

#if (defined _WIN32 || defined _WIN64)
#pragma warning (push)  ///< disable warning 4244 4267 from google/protobuf/text_format.h
#pragma warning (disable:4244 4267)
#include <hppdemo.pb.h>
#pragma warning (pop)   ///< disable warning 4244 4267 from google/protobuf/text_format.h end
#else
#include <hppdemo.pb.h>
#endif

static std::map<HPR_INT32, HPR_INT32> g_prime_num_list;

template<> inline HPR_INT32 PBWrap<hpp_demo::DemoAuthorizeReq>::DoTimeout()
{
    std::string s_client_name = GetMsg().client_name();
    HPP_ERROR("Found client %s authorization req timeout", s_client_name.c_str());

    return HPR_OK;
}

template<> inline WrapIf* PBWrap<hpp_demo::DemoAuthorizeRsp>::DoExecute()
{
    LOG_RECV_WRAP;

    hpp_demo::DemoAuthorizeRsp& r_msg = GetMsg();
    if (HPR_OK != r_msg.cmd().result_code())
    {
        LOG_ERROR("client authorization failed");
        CHPPDemoClient::Instance()->ShutDown();
    }
    else
    {
        LOG_INFO("client authorization success");
    }

    return NULL;
}

template<> inline WrapIf* PBWrap<hpp_demo::DemoCheckPrimeReq>::DoExecute()
{
    HPR_UINT32 n_start_time = 0;
    HPR_UINT32 n_stop_time = 0;

    hpp_demo::DemoCheckPrimeReq& r_msg = GetMsg();
    HPR_INT32 n_number_needs_check = r_msg.number_needs_check();

    n_start_time = HPR_GetTimeTick();
    HPR_BOOL b_prime = CHPPDemoClient::CheckPrime(n_number_needs_check);
    n_stop_time = HPR_GetTimeTick();

    if (b_prime)
    {
        if (10 == g_prime_num_list.size())
        {
            std::map<HPR_INT32, HPR_INT32>::iterator it = g_prime_num_list.begin();
            g_prime_num_list.erase(it);
        }
        g_prime_num_list.insert(std::make_pair(n_number_needs_check, n_stop_time - n_start_time));
    }

    PBWrap<hpp_demo::DemoCheckPrimeRsp>* p_rsp_wrap =
        PBWrapFactory<hpp_demo::DemoCheckPrimeRsp>::CreatePBWrap();
    if (NULL == p_rsp_wrap)
    {
        LOG_ERROR("Create DemoCheckPrimeRsp failed, no memory");
        return NULL;
    }

    hpp_demo::DemoCheckPrimeRsp& r_rsp_msg = p_rsp_wrap->GetMsg();
    hpp_demo::Cmd* p_rsp_cmd = r_rsp_msg.mutable_cmd();

    p_rsp_wrap->SetCommandId(hpp_demo::DEMO_CHECK_PRIME_RSP);
    p_rsp_wrap->SetInnerSequence(GetInnerSequence());
    p_rsp_wrap->SetMessageType(HPP_PACK_HEAD::RSP_MSG_FINISH);
    p_rsp_wrap->SetWrapDstId(GetWrapSrcId());

    r_rsp_msg.set_number_checked(n_number_needs_check);
    r_rsp_msg.set_result(b_prime);
    if (b_prime == HPR_TRUE)
    {
        r_rsp_msg.set_process_time(n_stop_time - n_start_time);
    }

    std::map<HPR_INT32, HPR_INT32>::iterator it;
    for (it = g_prime_num_list.begin(); it != g_prime_num_list.end(); ++it)
    {
        hpp_demo::PastPrimeNum* node = r_rsp_msg.add_past_prime_num_list();
        node->set_prime_num(it->first);
        node->set_process_time(it->second);
    }
    
    p_rsp_cmd->set_cmd_id(hpp_demo::DEMO_CHECK_PRIME_RSP);
    p_rsp_cmd->set_cmd_string("DemoCheckPrimeRsp");
    p_rsp_cmd->set_result_code(HPR_OK);
    p_rsp_cmd->set_result_string("OK");

    return p_rsp_wrap;
}


#endif // __DEMO_CLIENT_LOGIC_H__
