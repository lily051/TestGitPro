/** @file   hpp_demo_server.cpp
 *  @note   HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 *  @brief  
 *          
 *  @author fangyu@hikvision.com
 *  @date   2012/2/27
 */

#include "hpp_demo_server.h"
#include "demo_server_logic.h"

CHPPDemoServer* CHPPDemoServer::m_instance = NULL;
HPR_ATOMIC_T CHPPDemoServer::m_n_performance_recv_number = 0;

/** @fn     CHPPDemoServer::CHPPDemoServer()
 *  @brief  Constructor
 *  @param  void
 *  @return void
 */
CHPPDemoServer::CHPPDemoServer()
: m_h_hpp(NULL)
, m_s_local_ip("")
, m_n_local_port(0)
, m_s_password("")
, m_h_server(NULL)
, m_b_should_stop(HPR_FALSE)
, m_h_requester_thread(NULL)
, m_n_test_number(0)
{
}

/** @fn     CHPPDemoServer::~CHPPDemoServer()
 *  @brief  Destructor
 *  @param  void
 *  @return void
 */
CHPPDemoServer::~CHPPDemoServer()
{
    m_h_hpp = NULL;
    m_h_server = NULL;
    m_h_requester_thread = NULL;
}

/** @fn     CHPPDemoServer* CHPPDemoServer::Instance()
 *  @brief  Get HPP demo server instance
 *  @param  void
 *  @return HPP demo server instance
 */
CHPPDemoServer* CHPPDemoServer::Instance()
{
    if (m_instance == NULL)
    {
        m_instance = new (std::nothrow) CHPPDemoServer();
    }
    return m_instance;
}

/** @fn     void CHPPDemoServer::Free()
 *  @brief  Destroy HPP demo server instance
 *  @param  void
 *  @return void
 */
void CHPPDemoServer::Free()
{
    if (m_instance != NULL)
    {
        delete m_instance;
        m_instance = NULL;
    }
}

/** @fn     HPR_INT32 CHPPDemoServer::Init(HPP_HANDLE h_hpp_, const std::string& s_local_ip_, HPR_UINT16 n_local_port_, const std::string& s_password_, HPR_INT32 n_test_number_)
 *  @brief  Initialize HPP demo server
 *  @param  h_hpp_ [in] HPP handle
 *  @param  s_local_ip_ [in] local listener ip
 *  @param  n_local_port_ [in] local listener port
 *  @param  s_password_ [in] authorization password
 *  @param  n_test_number_ [in] test number
 *  @return success, HPR_OK; else, HPR_ERROR
 */
HPR_INT32 CHPPDemoServer::Init(HPP_HANDLE h_hpp_, const std::string& s_local_ip_, HPR_UINT16 n_local_port_, const std::string& s_password_, HPR_INT32 n_test_number_)
{
    if (h_hpp_ == NULL || s_local_ip_ == "" || n_local_port_ == 0 || s_password_ == "")
    {
        LOG_ERROR("Invalid Parameters found");
        return HPR_ERROR;
    }

    m_h_hpp = h_hpp_;
    m_s_local_ip = s_local_ip_;
    m_n_local_port = n_local_port_;
    m_s_password = s_password_;
    m_n_test_number = n_test_number_;

    return HPR_OK;
}

/** @fn     HPR_INT32 CHPPDemoServer::Finalize()
 *  @brief  Finalize HPP demo server
 *  @param  void
 *  @return HPR_OK
 */
HPR_INT32 CHPPDemoServer::Finalize()
{
    m_h_hpp = NULL;
    m_h_requester_thread = NULL;

    ///< stop all ConnSession
    for (clients::iterator it = m_clients.begin(); it != m_clients.end(); it++)
    {
        if (it->first != 0)
        {
            HPP_GetHppSessionById(it->first)->StopService();
        }
    }
    m_clients.clear();

    ///< stop all temp ConnSession
    for (size_t i = 0; i < m_tmp_session_list.size(); i++)
    {
        HPP_GetHppSessionById(m_tmp_session_list[i])->StopService();
    }
    m_tmp_session_list.clear();

    return HPR_OK;
}

/** @fn     HPR_INT32 CHPPDemoServer::StartUp()
 *  @brief  StartUp HPP demo server
 *  @param  void
 *  @return success, HPR_OK; else, HPR_ERROR
 */
HPR_INT32 CHPPDemoServer::StartUp()
{

#ifdef PERFORMANCE_TEST_SWITCH_ON
    m_h_requester_thread = HPR_Thread_Create(PerformanceTest, this, 0);
    if (NULL == m_h_requester_thread)
    {
        LOG_ERROR("start performance test thread failed");
        return HPR_ERROR;
    }
#else
    m_h_requester_thread = HPR_Thread_Create(CheckPrimeRequester, this, 0);
    if (NULL == m_h_requester_thread)
    {
        LOG_ERROR("start check prime requester failed");
        return HPR_ERROR;
    }
#endif

    ///< Start local server to accept clients
    m_h_server = HPP_StartLocalServer(m_h_hpp, m_s_local_ip.c_str(),
        m_n_local_port, OnAcceptClient, ConnSession::PROTOCOL_TYPE_HPP);
    if (NULL == m_h_server)
    {
        LOG_ERROR("start local server failed");
        return HPR_ERROR;
    }

    LOG_INFO("start local server(%s:%d) success",
        m_s_local_ip.c_str(), m_n_local_port);

    return HPR_OK;
}

/** @fn     HPR_INT32 CHPPDemoServer::ShutDown()
 *  @brief  ShutDown HPP demo server
 *  @param  void
 *  @return HPR_OK
 */
HPR_INT32 CHPPDemoServer::ShutDown()
{
    m_b_should_stop = HPR_TRUE;

    ///< stop local server
    if (m_h_server != NULL)
    {
        HPP_StopLocalServer(m_h_hpp, m_h_server);
        m_h_server = NULL;
    }

    if (m_h_requester_thread != NULL)
    {
        HPR_Thread_Wait(m_h_requester_thread);
        m_h_requester_thread = NULL;
    }

    return HPR_OK;
}

/** @fn     HPR_INT32 CHPPDemoServer::OnAcceptClient(ConnSession* p_conn_session_)
 *  @brief  Callback function when listener accept a client
 *  @param  p_conn_session_ [in] client session
 *  @return success, HPR_OK; else, HPR_ERROR
 */
HPR_INT32 CHPPDemoServer::OnAcceptClient(ConnSession* p_conn_session_)
{
    LOG_INFO("HPP demo server accept connection:%s, session id:%d.",
        p_conn_session_->GetSockRemoteIp(), p_conn_session_->GetSessionId());

    p_conn_session_->SetServiceType(0x3837);
    p_conn_session_->SetSocketClosedCallBack(OnSocketClosed);

    ///< start ConnSession
    if (HPR_OK != p_conn_session_->StartService(SERVICE_HIGH_PRI))
    {
        return HPR_ERROR;
    }

    return Instance()->AddSessionId(p_conn_session_->GetSessionId());
}

/** @fn     HPR_INT32 CHPPDemoServer::OnSocketClosed(ConnSession* p_conn_session_)
 *  @brief  Callback function when listener found session closed
 *  @param  p_conn_session_ [in] client session has been closed
 *  @return success, HPR_OK; else, HPR_ERROR
 */
HPR_INT32 CHPPDemoServer::OnSocketClosed(ConnSession* p_conn_session_)
{
    LOG_INFO("HPP demo server found connection closed, session id:%d", p_conn_session_->GetSessionId());

    return Instance()->RemoveSessionId(p_conn_session_->GetSessionId());
}

/** @fn     HPR_VOIDPTR CALLBACK CHPPDemoServer::CheckPrimeRequester(HPR_VOIDPTR p_user_data_)
 *  @brief  Callback function to create check primer requester thread
 *  @param  p_user_data_ [in] CHPPDemoServer instance pointer
 *  @return NULL
 */
HPR_VOIDPTR CALLBACK CHPPDemoServer::CheckPrimeRequester(HPR_VOIDPTR p_user_data_)
{
    CHPPDemoServer* p_server = (CHPPDemoServer*)p_user_data_;
    if (NULL != p_server)
    {
        p_server->CheckPrimeRequesterThread();
    }
    return NULL;
}

/** @fn     HPR_VOID CHPPDemoServer::CheckPrimeRequesterThread()
 *  @brief  Check primer requester thread work function
 *  @param  void
 *  @return void
 */
HPR_VOID CHPPDemoServer::CheckPrimeRequesterThread()
{
    HPR_INT32 n_number_needs_check = 0;
    while (HPR_TRUE != m_b_should_stop)
    {
        {
            HPR_Guard lock(&m_client_map_mutex);
            for (clients::iterator it = m_clients.begin(); it != m_clients.end(); it++)
            {
                PBWrap<hpp_demo::DemoCheckPrimeReq>* p_req_wrap = PBWrapFactory<hpp_demo::DemoCheckPrimeReq>::CreatePBWrap();
                if (p_req_wrap == NULL)
                {
                    LOG_ERROR("Create DemoCheckPrimeReq wrap failed, no memory");
                    continue;
                }

                hpp_demo::DemoCheckPrimeReq& r_req_msg = p_req_wrap->GetMsg();
                hpp_demo::Cmd* p_req_cmd = r_req_msg.mutable_cmd();

                p_req_wrap->SetCommandId(hpp_demo::DEMO_CHECK_PRIME_REQ);
                p_req_wrap->SetInnerSequence(HPP_GetUnRepeatSeq());
                p_req_wrap->SetMessageType(HPP_PACK_HEAD::REQ_MSG_NEED_RSP);
                p_req_wrap->SetWrapDstId(it->first);

                r_req_msg.set_number_needs_check(n_number_needs_check++);

                p_req_cmd->set_cmd_id(hpp_demo::DEMO_CHECK_PRIME_REQ);
                p_req_cmd->set_cmd_string("DemoCheckPrimeReq");

                LOG_SEND_WRAP(p_req_wrap);
                if (HPR_OK != ConnSession::SendMessage_r(p_req_wrap, it->first))
                {
                    LOG_ERROR("Send DemoCheckPrimeReq failed");
                    PBWrapFactory<hpp_demo::DemoCheckPrimeReq>::DestroyPBWrap(p_req_wrap);
                }
            }
        }

        ///< check every 50ms if application should stop during 1s sleeping
        for (int i = 0; i < 20; i++)
        {
            if (HPR_TRUE == m_b_should_stop)
            {
                break;
            }
            HPR_Sleep(50);
        }
    }
}

/** @fn     HPR_VOIDPTR CALLBACK CHPPDemoServer::PerformanceTest(HPR_VOIDPTR p_user_data_)
 *  @brief  Callback function to create performance test thread
 *  @param  p_user_data_ [in] should be CHPPDemoServer instance pointer
 *  @return NULL
 */
HPR_VOIDPTR CALLBACK CHPPDemoServer::PerformanceTest(HPR_VOIDPTR p_user_data_)
{
    CHPPDemoServer* p_server = (CHPPDemoServer*)p_user_data_;
    if (NULL != p_server)
    {
        p_server->PerformanceTestThread();
    }
    return NULL;
}

/** @fn     HPR_VOID CHPPDemoServer::PerformanceTestThread()
 *  @brief  Performance test thread
 *  @param  void
 *  @return void
 */
HPR_VOID CHPPDemoServer::PerformanceTestThread()
{
    bool enable_two_client_test = false;
    HPR_INT32 n_cur_test_number = -1;
    HPR_UINT32 n_start_time = 0;
    HPR_UINT32 n_stop_time = 0;
    HPR_INT32 n_number_needs_check = 1;
    HPR_INT32 n_session_id = 0;
    HPR_INT32 n_test_number = m_n_test_number;
    ConnSession* session_list[2];

    if (enable_two_client_test)
    {
        while (n_session_id == 0)
        {
            HPR_Guard lock(&m_client_map_mutex);

            if (m_clients.size() == 2)
            {
                clients::iterator it = m_clients.begin();
                n_session_id = it->first;
                session_list[0] = HPP_GetHppSessionById(n_session_id);
                if (session_list[0] == NULL)
                {
                    LOG_ERROR("Test Error, Get HPP Session Error");
                    return;
                }

                it++;
                n_session_id = it->first;
                session_list[1] = HPP_GetHppSessionById(n_session_id);
                if (session_list[1] == NULL)
                {
                    LOG_ERROR("Test Error, Get HPP Session Error");
                    return;
                }

                LOG_WARN("Session_1:[%d], Session_2[%d]", session_list[0], session_list[1]);

                break;
            }
        }

        n_start_time = HPR_GetTimeTick();
        for (int i = 0; i < n_test_number; i++)
        {
            for (int j = 0; j < 2; j++)
            {
                PBWrap<hpp_demo::DemoCheckPrimeReq>* p_req_wrap = PBWrapFactory<hpp_demo::DemoCheckPrimeReq>::CreatePBWrap();
                if (p_req_wrap == NULL)
                {
                    LOG_ERROR("Create DemoCheckPrimeReq wrap failed, no memory");
                    continue;
                }

                hpp_demo::DemoCheckPrimeReq& r_req_msg = p_req_wrap->GetMsg();
                hpp_demo::Cmd* p_req_cmd = r_req_msg.mutable_cmd();

                p_req_wrap->SetCommandId(hpp_demo::DEMO_CHECK_PRIME_REQ);
                p_req_wrap->SetInnerSequence(HPP_GetUnRepeatSeq());
                p_req_wrap->SetMessageType(HPP_PACK_HEAD::REQ_MSG_NEED_RSP);
                //p_req_wrap->SetWrapDstId(n_session_id);

                r_req_msg.set_number_needs_check(n_number_needs_check);

                p_req_cmd->set_cmd_id(hpp_demo::DEMO_CHECK_PRIME_REQ);
                p_req_cmd->set_cmd_string("DemoCheckPrimeReq");

                if (HPR_OK != session_list[j]->SendMessage(p_req_wrap))
                {
                    i--;    ///< Message should be sent again
                    LOG_ERROR("Performance test send DemoCheckPrimeReq failed");
                    PBWrapFactory<hpp_demo::DemoCheckPrimeReq>::DestroyPBWrap(p_req_wrap);
                    for (int j = 0; j < 10; j++)
                    {
                        if (HPR_TRUE == m_b_should_stop)
                        {
                            break;
                        }
                        HPR_Sleep(50);
                    }
                }
            }

            if (HPR_TRUE == m_b_should_stop)
            {
                LOG_ERROR("Test Abort");
                n_cur_test_number = i;
                break;
            }
        }
        n_stop_time = HPR_GetTimeTick();
    }
    else
    {
        while (n_session_id == 0)
        {
            HPR_Guard lock(&m_client_map_mutex);

            if (m_clients.size() >= 1)
            {
                clients::iterator it = m_clients.begin();
                n_session_id = it->first;
                session_list[0] = HPP_GetHppSessionById(n_session_id);
                if (session_list[0] == NULL)
                {
                    LOG_ERROR("Test Error, Get HPP Session Error");
                    return;
                }

                LOG_WARN("Session_1:[%d]", session_list[0]);

                break;
            }
            else
            {
                HPR_Sleep(10);
            }
        }

        n_start_time = HPR_GetTimeTick();
        //for (int i = 0; i < n_test_number; i++)
        while (!m_b_should_stop)
        {
            for (int i = 0; i < 17500; i++)
            {
                PBWrap<hpp_demo::DemoCheckPrimeReq>* p_req_wrap = PBWrapFactory<hpp_demo::DemoCheckPrimeReq>::CreatePBWrap();
                if (p_req_wrap == NULL)
                {
                    LOG_ERROR("Create DemoCheckPrimeReq wrap failed, no memory");
                    continue;
                }

                hpp_demo::DemoCheckPrimeReq& r_req_msg = p_req_wrap->GetMsg();
                hpp_demo::Cmd* p_req_cmd = r_req_msg.mutable_cmd();

                p_req_wrap->SetCommandId(hpp_demo::DEMO_CHECK_PRIME_REQ);
                p_req_wrap->SetInnerSequence(HPP_GetUnRepeatSeq());
                p_req_wrap->SetMessageType(HPP_PACK_HEAD::REQ_MSG_NEED_RSP);
                //p_req_wrap->SetWrapDstId(n_session_id);

                r_req_msg.set_number_needs_check(n_number_needs_check);

                p_req_cmd->set_cmd_id(hpp_demo::DEMO_CHECK_PRIME_REQ);
                p_req_cmd->set_cmd_string("DemoCheckPrimeReq");

                //LOG_ERROR("Wrap size: %d", p_req_wrap->GetContentLen());

                if (HPR_OK != session_list[0]->SendMessage(p_req_wrap))
                {
                    i--;    ///< Message should be sent again
                    LOG_ERROR("Performance test send DemoCheckPrimeReq failed");
                    PBWrapFactory<hpp_demo::DemoCheckPrimeReq>::DestroyPBWrap(p_req_wrap);
                    for (int j = 0; j < 10; j++)
                    {
                        if (HPR_TRUE == m_b_should_stop)
                        {
                            break;
                        }
                        HPR_Sleep(50);
                    }
                }

                if (HPR_TRUE == m_b_should_stop)
                {
                    LOG_ERROR("Test Abort");
                    n_cur_test_number = i;
                    break;
                }
            }
            HPR_Sleep(500);
        }

        n_stop_time = HPR_GetTimeTick();
    }

    ///< not run into test abort branch
    if (n_cur_test_number == -1)
    {
        n_cur_test_number = n_test_number;
    }

    LOG_WARN("Test result: sending %d message, using %d ms.", n_test_number, n_stop_time - n_start_time);
}

/** @fn     void CHPPDemoServer::IncRecvNumber()
 *  @brief  Rsp counter
 *  @param  void
 *  @return void
 */
void CHPPDemoServer::IncRecvNumber()
{
    HPR_AtomicInc(&m_n_performance_recv_number);

    if (PERFORMANCE_TEST_NUM + PERFORMANCE_TEST_NUM == m_n_performance_recv_number)
    {
        LOG_WARN("Performance Test Last Rsp Has Received");
    }
}

/** @fn     HPR_BOOL CHPPDemoServer::Authorize(const std::string& s_password_)
 *  @brief  Authorize client password
 *  @param  s_password_ [in] password
 *  @return authorized, HPR_TRUE; else, HPR_FALSE
 */
HPR_BOOL CHPPDemoServer::Authorize(const std::string& s_password_)
{
    return s_password_ == m_s_password ? HPR_TRUE : HPR_FALSE;
}

/** @fn     HPR_INT32 CHPPDemoServer::AddSessionId(HPR_INT32 n_session_id_, const std::string& s_name_ = "")
 *  @brief  Add session id to tmp list or client map
 *  @param  n_session_id_ [in] session id
 *  @param  s_name_ [in] client name, default to ""
 *  @return success, HPR_OK; else, HPR_ERROR;
 */
HPR_INT32 CHPPDemoServer::AddSessionId(HPR_INT32 n_session_id_, const std::string& s_name_ /* = "" */)
{
    HPR_Guard lock(&m_client_map_mutex);
    if (s_name_ == "")
    {
        for (tmp_session_list::iterator it = m_tmp_session_list.begin(); it != m_tmp_session_list.end(); it++)
        {
            if (*it == n_session_id_)
            {
                LOG_ERROR("Session already exist");
                return HPR_ERROR;
            }
        }
        m_tmp_session_list.push_back(n_session_id_);
        return HPR_OK;
    }
    else
    {
        bool b_tmp_session_found = false;
        for (tmp_session_list::iterator it = m_tmp_session_list.begin(); it != m_tmp_session_list.end(); it++)
        {
            if (*it == n_session_id_)
            {
                m_tmp_session_list.erase(it);
                b_tmp_session_found = true;
                break;
            }
        }

        if (!b_tmp_session_found)
        {
            LOG_ERROR("Unknow session found");
            return HPR_ERROR;
        }

        clients::iterator it = m_clients.find(n_session_id_);
        if (it != m_clients.end())
        {
            LOG_ERROR("Session %d to client %s already exit", it->first, it->second.c_str());
            return HPR_ERROR;
        }
        else
        {
            LOG_INFO("Session %d to client %s add to client map", n_session_id_, s_name_.c_str());
            m_clients.insert(clients::value_type(n_session_id_, s_name_));
            return HPR_OK;
        }
    }
}

/** @fn     HPR_INT32 CHPPDemoServer::RemoveSessionId(HPR_INT32 n_session_id_)
 *  @brief  Remove session id from tmp list or client map
 *  @param  n_session_id_ [in] session id
 *  @return success, HPR_OK; else, HPR_ERROR
 */
HPR_INT32 CHPPDemoServer::RemoveSessionId(HPR_INT32 n_session_id_)
{
    HPR_Guard lock(&m_client_map_mutex);

    bool b_tmp_session_found = false;
    for (tmp_session_list::iterator it = m_tmp_session_list.begin(); it != m_tmp_session_list.end(); it++)
    {
        if (*it == n_session_id_)
        {
            m_tmp_session_list.erase(it);
            b_tmp_session_found = true;
            break;
        }
    }
    if (b_tmp_session_found)
    {
        LOG_INFO("Remove tmp session %d", n_session_id_);
        return HPR_OK;
    }

    clients::iterator it = m_clients.find(n_session_id_);
    if (it != m_clients.end())
    {
        LOG_ERROR("Remove session %d to client %s", it->first, it->second.c_str());
        m_clients.erase(it);
        return HPR_OK;
    }

    LOG_ERROR("Found session %d not exist", n_session_id_);
    return HPR_ERROR;
}
