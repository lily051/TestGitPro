/** @file   hpp_demo_client.h
 *  @note   HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 *  @brief  
 *          
 *  @author fangyu@hikvision.com
 *  @date   2012/2/27
 */

#ifndef __HPP_DEMO_CLIENT_H__
#define __HPP_DEMO_CLIENT_H__

#include <hpp/hpp_hpp.h>
#include <hpr/hpr_utils.h>
#include <hlog/hlog.h>
#include <string>


#define LOG_RECV_WRAP \
{\
    std::string s_recv_message;\
    PrintToString(&s_recv_message);\
    HPP_TRACE("Recv Message: %s", s_recv_message.c_str());\
}

#define LOG_SEND_WRAP(p_wrap) \
{\
    std::string s_send_message;\
    p_wrap->GetContentLen();\
    p_wrap->PrintToString(&s_send_message);\
    HPP_TRACE("Send Message: %s", s_send_message.c_str());\
}

class CHPPDemoClient
{
public:
    CHPPDemoClient();
    ~CHPPDemoClient();

    static CHPPDemoClient* Instance();
    static HPR_VOID Free();

    HPR_INT32 Init(HPP_HANDLE h_hpp_, const std::string& s_name_, const std::string& s_password_, const std::string& s_server_ip_, HPR_UINT16 n_server_port_);
    HPR_INT32 Finalize();

    HPR_INT32 StartUp();
    HPR_INT32 ShutDown();

    static HPR_INT32 OnConnectionClosed(ConnSession* p_conn_session_);
    static HPR_INT32 OnConnectionComplete(ConnSession* p_conn_session_);
    static HPR_INT32 OnConnectionError(HPR_VOIDPTR p_user_data_);

    WrapIf* FormAuthorizationWrap();
    static HPR_BOOL CheckPrime(HPR_INT32 n_number_needs_check_);

    HPR_INT32 ServerSessionId() const                       {   return m_n_server_session_id;                   }
    void ServerSessionId(HPR_INT32 n_server_session_id_)    {   m_n_server_session_id = n_server_session_id_;   }
    void ServerSession(ConnSession* p_server_session_)      {   m_p_server_session = p_server_session_;         }

private:

    HPP_HANDLE m_h_hpp;

    std::string m_s_name;
    std::string m_s_password;

    std::string m_s_server_ip;
    HPR_UINT16 m_n_server_port;

    HPR_INT32 m_n_server_session_id;
    ConnSession* m_p_server_session;

    static CHPPDemoClient* m_instance;
};

#endif // __HPP_DEMO_CLIENT_H__
