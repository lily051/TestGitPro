/** @file   demo_server_logic.h
 *  @note   HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 *  @brief  
 *          
 *  @author fangyu@hikvision.com
 *  @date   2012/2/27
 */

#ifndef __DEMO_SERVER_LOGIC_H__
#define __DEMO_SERVER_LOGIC_H__

#include <hpp/hpp_hpp.h>
#include "hpp_demo_server.h"

#if (defined _WIN32 || defined _WIN64)
#pragma warning (push)  ///< disable warning 4244 4267 from google/protobuf/text_format.h
#pragma warning (disable:4244 4267)
#include <hppdemo.pb.h>
#pragma warning (pop)   ///< disable warning 4244 4267 from google/protobuf/text_format.h end
#else
#include <hppdemo.pb.h>
#endif

template<> inline WrapIf* PBWrap<hpp_demo::DemoAuthorizeReq>::DoExecute()
{
    LOG_RECV_WRAP;

    HPR_INT32 n_ret = HPR_OK;
    hpp_demo::DemoAuthorizeReq& r_req_msg = GetMsg();
    if (HPR_TRUE != CHPPDemoServer::Instance()->Authorize(r_req_msg.password()))
    {
        LOG_ERROR("client %s authorized failed", r_req_msg.client_name().c_str());
        n_ret = HPR_ERROR;
    }
    else
    {
        if (HPR_OK != CHPPDemoServer::Instance()->AddSessionId(GetWrapSrcId(), r_req_msg.client_name()))
        {
            n_ret = HPR_ERROR;
        }
    }


    PBWrap<hpp_demo::DemoAuthorizeRsp>* p_rsp_wrap = PBWrapFactory<hpp_demo::DemoAuthorizeRsp>::CreatePBWrap();
    hpp_demo::Cmd* p_rsp_cmd = p_rsp_wrap->GetMsg().mutable_cmd();

    p_rsp_wrap->SetCommandId(hpp_demo::DEMO_AUTHORIZE_RSP);
    p_rsp_wrap->SetInnerSequence(GetInnerSequence());
    p_rsp_wrap->SetMessageType(HPP_PACK_HEAD::RSP_MSG_FINISH);
    p_rsp_wrap->SetWrapDstId(GetWrapSrcId());

    p_rsp_cmd->set_cmd_id(hpp_demo::DEMO_AUTHORIZE_RSP);
    p_rsp_cmd->set_cmd_string("DemoAuthorizeRsp");
    p_rsp_cmd->set_result_code(n_ret);
    if (HPR_OK == n_ret)
    {
        p_rsp_cmd->set_result_string("OK");
    }
    else
    {
        p_rsp_cmd->set_result_string("Error");
    }

    LOG_SEND_WRAP(p_rsp_wrap);

    return p_rsp_wrap;
}

template<> inline WrapIf* PBWrap<hpp_demo::DemoCheckPrimeRsp>::DoExecute()
{
#ifndef PERFORMANCE_TEST_SWITCH_ON
    LOG_RECV_WRAP;

    hpp_demo::DemoCheckPrimeRsp& r_msg = GetMsg();

    if (r_msg.has_process_time())
    {
        LOG_INFO("%d %s a prime number. client process time %dms", r_msg.number_checked(), r_msg.result() == HPR_TRUE ? "is" : "is not", r_msg.process_time());
    }
    else
    {
        LOG_INFO("%d %s a prime number.", r_msg.number_checked(), r_msg.result() == HPR_TRUE ? "is" : "is not");
    }
    HPR_INT32 list_size = r_msg.past_prime_num_list_size();
    for (int i = 0; i < list_size; ++i)
    {
        LOG_INFO("one of last %d prime num befor %d is: %d, process time: %d",
            list_size, r_msg.number_checked(),
            r_msg.past_prime_num_list(i).prime_num(),
            r_msg.past_prime_num_list(i).process_time());
    }
#endif

#ifdef PERFORMANCE_TEST_SWITCH_ON
    CHPPDemoServer::IncRecvNumber();
#endif

    return NULL;
}


#endif // __DEMO_SERVER_LOGIC_H__
