// DemoDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Demo.h"
#include "DemoDlg.h"
#include <shlwapi.h>

#pragma comment(lib, "Shlwapi.lib")


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

class CAboutDlg;

//
CDemoDlg::CDemoDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CDemoDlg::IDD, pParent)
    , m_nPort(-1)
    , m_bRunning(FALSE)
    , m_nClientWidth(0)
    , m_nClientHeight(0)
    , m_hVideoWnd(NULL)
    , m_pWaveFormat(NULL)
{
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

//
void CDemoDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_BTN_START, m_btnStart);
    DDX_Control(pDX, IDC_BTN_STOP, m_btnStop);
    DDX_Control(pDX, IDC_BTN_SNAPSHOT, m_btnSnapShot);
    DDX_Control(pDX, IDC_COMBO1,  m_cmbVideo);
    DDX_Control(pDX, IDC_COMBO2,  m_cmbAudio);
    DDX_Control(pDX, IDC_COM_RESOLUTION,  m_cmbResolution);
    DDX_Control(pDX, IDC_COM_FRAMERATE,  m_cmbFrameRate);
    DDX_Control(pDX, IDC_COM_PREVIEW_TYPE,  m_cmbPreviewType);
    DDX_Control(pDX, IDC_COM_CAPTURE_TYPE,  m_cmbCaptureType);
    DDX_Control(pDX, IDC_COM_H264_BITRATE, m_cmbH264BitRate);
    DDX_Control(pDX, IDC_CHK_PREVIEW,  m_btnUsePreview);
    DDX_Control(pDX, IDC_CHK_CAPTURE,  m_btnUseCapture);
    DDX_Control(pDX, IDC_CHK_PREVIEW_AUDIO,  m_btnPreviewAudio);
    DDX_Control(pDX, IDC_CHK_CAPTURE_AUDIO,  m_btnCaptureAudio);
    DDX_Control(pDX, IDC_STATIC_PREVIEW_WINDOW, m_PreviewWindow);
    DDX_Control(pDX, IDC_COM_AUDIO_PROPERTY, m_cmbAudioProperty);
    DDX_Control(pDX, IDC_COM_CAPTURE_TIME, m_cmbCaptureTime);

    DDX_Text(pDX, IDC_COM_H264_BITRATE, m_dwH264BitRate);
    DDX_Text(pDX, IDC_COM_FRAMERATE, m_dwFrameRate);
    DDX_Text(pDX, IDC_COM_CAPTURE_TIME, m_dwCaptureTime);
    

}
//
BEGIN_MESSAGE_MAP(CDemoDlg, CDialog)
    ON_WM_SYSCOMMAND()
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    ON_WM_SIZE()
    ON_WM_CLOSE()
    ON_WM_GETMINMAXINFO()
    ON_CBN_DROPDOWN(IDC_COMBO1, &CDemoDlg::OnCbnDropdown_VideoDevice)
    ON_CBN_DROPDOWN(IDC_COMBO2, &CDemoDlg::OnCbnDropdown_AudioDevice)
    ON_WM_TIMER()
    ON_WM_DESTROY()
    ON_BN_CLICKED(IDC_BTN_START, &CDemoDlg::OnBnClickedBtnStart)
    ON_BN_CLICKED(IDC_BTN_STOP, &CDemoDlg::OnBnClickedBtnStop)
    ON_BN_CLICKED(IDC_BTN_SNAPSHOT, &CDemoDlg::OnBnClickedBtnSnapshot)
    ON_CBN_SELCHANGE(IDC_COMBO2, &CDemoDlg::OnCbnSelchangeCombo2)
END_MESSAGE_MAP()


// CDemoDlg ��Ϣ��������

BOOL CDemoDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    // ��������...���˵������ӵ�ϵͳ�˵��С�

    // IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
    ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
    ASSERT(IDM_ABOUTBOX < 0xF000);

    CMenu* pSysMenu = GetSystemMenu(FALSE);
    if (pSysMenu != NULL)
    {
        CString strAboutMenu;
        strAboutMenu.LoadString(IDS_ABOUTBOX);
        if (!strAboutMenu.IsEmpty())
        {
            pSysMenu->AppendMenu(MF_SEPARATOR);
            pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
        }
    }

    // ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�

    SetIcon(m_hIcon, TRUE);            // ���ô�ͼ��
    SetIcon(m_hIcon, FALSE);        // ����Сͼ��

    // TODO: �ڴ����Ӷ���ĳ�ʼ������

    USBCamera_InitSDK();

    //������־
    char* szLogPath = "./UsbCameraSDKLog/";
    USBCamera_SetLogToFile(3, szLogPath, FALSE);

    m_dwFilter = USBCAMERA_DS_2CS54D0B; /*USBCAMERA_ALL  USBCAMERA_DS_2CS54D0B*/
    //USBCAMERA_DS_2CS54D2B //USBCAMERA_DS_2CS54C2B
    BOOL bRet = USBCamera_SetFilter(m_dwFilter);    

    // ö���豸
    OnCbnDropdown_AudioDevice();    // ѡ����Ƶ�豸
    OnCbnDropdown_VideoDevice();    // ѡ����Ƶ�豸

    // ��ȡ����ͨ����
    m_nPort = -1;
    USBCamera_GetPort(&m_nPort);

    if (m_dwFilter == USBCAMERA_DS_2CS54D2B)
    {
        m_cmbResolution.InsertString(0, L"1920*1080");
        m_cmbResolution.InsertString(1, L"1712*960");
        m_cmbResolution.InsertString(2, L"1280*960");
        m_cmbResolution.InsertString(3, L"1280*720");
        m_cmbResolution.InsertString(4, L"800*600");
        m_cmbResolution.InsertString(5, L"848*480");
        m_cmbResolution.InsertString(6, L"640*480");
        m_cmbResolution.InsertString(7, L"640*360");
        m_cmbResolution.InsertString(8, L"432*240");
        m_cmbResolution.InsertString(9, L"352*288");

        m_cmbResolution.SetCurSel(9);
    }
    else
    {
        m_cmbResolution.InsertString(0, L"1920*1080");
        m_cmbResolution.InsertString(1, L"1280*720");
        m_cmbResolution.InsertString(2, L"640*480");
        m_cmbResolution.InsertString(3, L"320*240");
        m_cmbResolution.SetCurSel(3);
    }

    m_cmbFrameRate.InsertString(0, L"10");
    m_cmbFrameRate.InsertString(1, L"15");
    m_cmbFrameRate.InsertString(2, L"20");
    m_cmbFrameRate.InsertString(3, L"25");
    m_cmbFrameRate.InsertString(4, L"30");
    m_cmbFrameRate.SetCurSel(3);
    m_dwFrameRate = 25;

    m_cmbPreviewType.InsertString(0, L"MJPEG");
    m_cmbPreviewType.InsertString(1, L"PS");
    m_cmbPreviewType.SetCurSel(1);

    m_cmbCaptureType.InsertString(0, L"H264");
    m_cmbCaptureType.InsertString(1, L"PS");
    m_cmbCaptureType.InsertString(2, L"MJPEG");
    m_cmbCaptureType.SetCurSel(1);

    RECT rc;
    m_PreviewWindow.GetClientRect(&rc);
    m_nClientWidth = rc.right - rc.left;   // ��
    m_nClientHeight = rc.bottom - rc.top ;   // ��

    m_btnStop.EnableWindow(FALSE);
    m_btnSnapShot.EnableWindow(FALSE);

    m_btnUsePreview.SetCheck(TRUE);
    m_btnUseCapture.SetCheck(TRUE);

    m_btnPreviewAudio.SetCheck(FALSE);
    m_btnCaptureAudio.SetCheck(TRUE);

    m_dwH264BitRate = 110;
    m_cmbH264BitRate.SetCurSel(8);

    m_cmbCaptureTime.SetCurSel(0);

    return TRUE;
}


void CDemoDlg::OnBnClickedBtnSnapshot()
{
    if (!m_bRunning)
    {
        AfxMessageBox(TEXT("δ��������״̬������ץͼ"));
        return ;
    }

    WCHAR wszJPGFile[_MAX_PATH] = {0};  
    SYSTEMTIME stUTC;
    ::GetLocalTime(&stUTC);

    swprintf_s(wszJPGFile, _MAX_PATH, TEXT("./Snapshot/%d-%02d-%02d %02d.%02d.%02d.jpg"), 
        stUTC.wYear, stUTC.wMonth, stUTC.wDay, stUTC.wHour, stUTC.wMinute, stUTC.wSecond);

    USBCamera_Snapshot(m_nPort, wszJPGFile);
}

void __stdcall CDemoDlg::DecCallBack(LONG nPort, unsigned char *pBuf, long nSize, FRAME_INFO *pFrameInfo, void* pUser)
{
    if (pFrameInfo->nType == USBCAMERA_PCM)
    {
//         CString strInfo;
//         strInfo.Format(L"PCM-%d\n", pFrameInfo->nType);
//         OutputDebugString(strInfo);
    }
    else if (pFrameInfo->nType == USBCAMERA_PS_H264 || pFrameInfo->nType == USBCAMERA_PS_H264_PCM)
    {

//         CString strInfo;
//         strInfo.Format(L"Time[%d] PS-%d\n", pFrameInfo->lStamp, pFrameInfo->nType);
//         OutputDebugString(strInfo);
    }
    else if (pFrameInfo->nType == USBCAMERA_H264)
    {
//         CString strInfo;
//         strInfo.Format(L"H264-%d\n", pFrameInfo->nType);
//         OutputDebugString(strInfo);
    }
}

void CDemoDlg::OnBnClickedBtnStart()
{
    UpdateData(TRUE);

    m_hVideoWnd = m_PreviewWindow.GetSafeHwnd();

    BOOL ret = FALSE;
    DWORD dwWidth = 0;
    DWORD dwHeight = 0;

    if (m_cmbVideo.GetCount() == 0 || m_cmbAudio.GetCount() == 0)
    {
        AfxMessageBox(TEXT("��ѡ��ҪԤ�����豸"));
        return ;
    }

    int vIndex = m_cmbVideo.GetCurSel();
    int aIndex = m_cmbAudio.GetCurSel();
    
    if(vIndex < 0 || aIndex < 0)
    {
        AfxMessageBox(TEXT("��ѡ��ҪԤ�����豸"));
        return ;
    }

    HANDLE vDevice = NULL, aDevice = NULL;

    USBCamera_GetVideoDevice(vIndex, &vDevice);
    USBCamera_GetAudioDevice(aIndex, &aDevice);


    // ѡ���Ԥ���豸
    ret = USBCamera_ChooseDevice(m_nPort, vDevice, aDevice);
    if(!ret)
    {
        // ��ʼ���豸ʧ��
        AfxMessageBox(TEXT("�豸��ʼ��ʧ��"));
        return;
    }

    CAMERA_CAPACITY* pCameraCapacity = NULL;
    int nCamCapCount = 0;
    USBCamera_EnumVideoProperty(m_nPort, &pCameraCapacity, &nCamCapCount);

    CAMERA_CAPACITY aCamCap[128] = {0};
    memcpy(aCamCap, pCameraCapacity, nCamCapCount * sizeof(CAMERA_CAPACITY));

    WAVEFORMATEX *pWF = NULL;
    int nAudioCapCount = 0;
    USBCamera_EnumAudioFormat(m_nPort, &pWF, &nAudioCapCount);

    WAVEFORMATEX aAudioCap[128] = {0};
    memcpy(aAudioCap, pWF, nAudioCapCount * sizeof(WAVEFORMATEX));

    //����H264����
    USBCamera_SetBitRate(m_nPort, m_dwH264BitRate);

    //����֡��
    USBCamera_SetFrameRate(m_nPort, m_dwFrameRate);

    USBCamera_GetFrameRate(m_nPort, &m_dwFrameRate);

    // ���÷ֱ���
    int nResolutionIndex = m_cmbResolution.GetCurSel();
    if (m_dwFilter == USBCAMERA_DS_2CS54D2B)
    {
        m_cmbResolution.InsertString(0, L"1920*1080");
        m_cmbResolution.InsertString(1, L"1712*960");
        m_cmbResolution.InsertString(2, L"1280*960");
        m_cmbResolution.InsertString(3, L"1280*720");
        m_cmbResolution.InsertString(4, L"800*600");
        m_cmbResolution.InsertString(5, L"848*480");
        m_cmbResolution.InsertString(6, L"640*480");
        m_cmbResolution.InsertString(7, L"640*360");
        m_cmbResolution.InsertString(8, L"432*240");
        m_cmbResolution.InsertString(9, L"352*288");

        if (nResolutionIndex == 0)
        {
            USBCamera_SetResolution(m_nPort, 1920, 1080);
        }
        else if (nResolutionIndex == 1)
        {
            USBCamera_SetResolution(m_nPort, 1712, 960);
        }
        else if (nResolutionIndex == 2)
        {
            USBCamera_SetResolution(m_nPort, 1280, 960);
        }
        else if (nResolutionIndex == 3)
        {
            USBCamera_SetResolution(m_nPort, 1280, 720);
        }
        else if (nResolutionIndex == 4)
        {
            USBCamera_SetResolution(m_nPort, 800, 600);
        }
        else if (nResolutionIndex == 5)
        {
            USBCamera_SetResolution(m_nPort, 848, 480);
        }
        else if (nResolutionIndex == 6)
        {
            USBCamera_SetResolution(m_nPort, 640, 480);
        }
        else if (nResolutionIndex == 7)
        {
            USBCamera_SetResolution(m_nPort, 640, 360);
        }
        else if (nResolutionIndex == 8)
        {
            USBCamera_SetResolution(m_nPort, 432, 240);
        }
        else
        {
            USBCamera_SetResolution(m_nPort, 352, 288);
        }
    }
    else
    {
        if (nResolutionIndex == 0)
        {
            USBCamera_SetResolution(m_nPort, 1920, 1080);
        }
        else if (nResolutionIndex == 1)
        {
            USBCamera_SetResolution(m_nPort, 1280, 720);
        }
        else if (nResolutionIndex == 2)
        {
            USBCamera_SetResolution(m_nPort, 640, 480);
        }
        else
        {
            USBCamera_SetResolution(m_nPort, 320, 240);
        }
    }

    //���������ص�
    DEC_CALLBACK_INFO struDecCbInfo = {0};
    struDecCbInfo.dwVideoFormat = USBCAMERA_PS_H264_PCM;
    struDecCbInfo.dwAudioFormat = 0;
    struDecCbInfo.lPort = m_nPort;
    struDecCbInfo.pUser = this;
    struDecCbInfo.fnDevCb = CDemoDlg::DecCallBack;
    USBCamera_SetDecCallBack(m_nPort, struDecCbInfo);

    //�����������ʵ���Ϣ
    WAVEFORMATEX wf;
    USBCamera_GetAudioFormat(m_nPort, &wf);

    wf.nChannels = 1;   // ��ͨ��
    wf.nSamplesPerSec = 8000;   // ������
    wf.wBitsPerSample = 16;
    wf.nBlockAlign = 2;

//     wf.nChannels = 1;   // ��ͨ��
//     wf.nSamplesPerSec = 8000;   // ������
//     wf.wBitsPerSample = 8;
//     wf.nBlockAlign = 1;

    wf.nAvgBytesPerSec =  wf.nSamplesPerSec * wf.nBlockAlign;
    USBCamera_SetAudioFormat(m_nPort, wf);

    memset(&wf, 0, sizeof(wf));

    USBCamera_GetAudioFormat(m_nPort, &wf);

    //����Ԥ������
    if (m_btnUsePreview.GetCheck() == BST_CHECKED)
    {
        int nPreviewTypeIndex = m_cmbPreviewType.GetCurSel();
        int nPreviewType = USBCAMERA_PS_H264;
        if (nPreviewTypeIndex == 0)
        {
            nPreviewType = USBCAMERA_MJPEG;
        }
        else
        {
            if (m_btnPreviewAudio.GetCheck() == BST_CHECKED)
            {
                nPreviewType = USBCAMERA_PS_H264_PCM;
            }
            else
            {
                nPreviewType = USBCAMERA_PS_H264;
            }
        }
        BOOL bPreviewAudio = TRUE;
        if (m_btnPreviewAudio.GetCheck() != BST_CHECKED)
        {
            bPreviewAudio = FALSE;
        }
        ret = USBCamera_SetPreview(m_nPort, nPreviewType, bPreviewAudio, m_hVideoWnd);
    }

    //����¼�����
    if (m_btnUseCapture.GetCheck() == BST_CHECKED)
    {
        WCHAR wszCaptureFile[_MAX_PATH] = {0};  
        SYSTEMTIME stUTC;
        ::GetLocalTime(&stUTC);

        int nCaptureTypeIndex = m_cmbCaptureType.GetCurSel();
        int nCaptureType = USBCAMERA_H264;
        if (nCaptureTypeIndex == 0)
        {
            nCaptureType = USBCAMERA_H264;
            swprintf_s(wszCaptureFile, _MAX_PATH, TEXT("./Capture/%d-%02d-%02d %02d.%02d.%02d.avi"), 
                stUTC.wYear, stUTC.wMonth, stUTC.wDay, stUTC.wHour, stUTC.wMinute, stUTC.wSecond);
        }
        else if (nCaptureTypeIndex == 1)
        {
            if (m_btnCaptureAudio.GetCheck() == BST_CHECKED)
            {
                nCaptureType = USBCAMERA_PS_H264_PCM;
            }
            else
            {
                nCaptureType = USBCAMERA_PS_H264;
            }
            
            swprintf_s(wszCaptureFile, _MAX_PATH, TEXT("./Capture/%d-%02d-%02d %02d.%02d.%02d.ps"), 
                stUTC.wYear, stUTC.wMonth, stUTC.wDay, stUTC.wHour, stUTC.wMinute, stUTC.wSecond);
        }
        else
        {
            nCaptureType = USBCAMERA_MJPEG;
            swprintf_s(wszCaptureFile, _MAX_PATH, TEXT("./Capture/%d-%02d-%02d %02d.%02d.%02d.wmv"), 
                stUTC.wYear, stUTC.wMonth, stUTC.wDay, stUTC.wHour, stUTC.wMinute, stUTC.wSecond);
        }
         
        BOOL bCaptureAudio = TRUE;
        if (m_btnCaptureAudio.GetCheck() != BST_CHECKED)
        {
            bCaptureAudio = FALSE;
        }

        ret = USBCamera_SetCapture(m_nPort, nCaptureType, bCaptureAudio, wszCaptureFile);
    }

    //����
    ret = USBCamera_Start(m_nPort);

    if (ret)
    {
        m_bRunning = true;

        if (m_btnUseCapture.GetCheck() == BST_CHECKED)
        {
            if (m_dwCaptureTime != 0)
            {
                int nTime = m_dwCaptureTime * 1000;
                SetTimer(1, nTime, NULL);
            }
        }

        m_btnStart.EnableWindow(FALSE);
        m_btnStop.EnableWindow(TRUE);
        m_btnSnapShot.EnableWindow(TRUE);
        //m_cmbVideo.EnableWindow(FALSE);
        //m_cmbAudio.EnableWindow(FALSE);
        m_cmbResolution.EnableWindow(FALSE);
        m_cmbFrameRate.EnableWindow(FALSE);

        USBCamera_GetResolution(m_nPort, &dwWidth, &dwHeight);

        AdapterWindow(dwWidth, dwHeight, 2);
    }
    else 
    {
        int nError = USBCamera_GetLastError();
        AfxMessageBox(TEXT("Ԥ��ʧ��"));
    }
}

void CDemoDlg::OnBnClickedBtnStop()
{
    BOOL ret = FALSE;

    KillTimer(1);

    ret = USBCamera_Stop(m_nPort);
    USBCamera_FreeDevice(m_nPort);

    m_bRunning = FALSE;

    m_btnStart.EnableWindow(TRUE);
    m_btnStop.EnableWindow(FALSE);
    m_btnSnapShot.EnableWindow(FALSE);
    m_cmbVideo.EnableWindow(TRUE);
    m_cmbAudio.EnableWindow(TRUE);
    m_cmbResolution.EnableWindow(TRUE);
    m_cmbFrameRate.EnableWindow(TRUE);
}


//
void CDemoDlg::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
    lpMMI->ptMinTrackSize.x = 720;
    lpMMI->ptMinTrackSize.y = 530;
    CDialog::OnGetMinMaxInfo(lpMMI);
}


void CDemoDlg::OnCbnDropdown_VideoDevice()
{
    m_cmbVideo.ResetContent();

    BOOL ret = FALSE;
    int nDeviceNum = 0;
    WCHAR friendlyName[512];
    DWORD retBufSize;

    ret = USBCamera_EnumVideoDevice(&nDeviceNum);
    
    for (int i = 0; i < nDeviceNum; i++)
    {
        HANDLE vDevice = NULL;
        USBCamera_GetVideoDevice(i, &vDevice);
        ret = USBCamera_GetDeviceFriendlyName(vDevice, (LPWSTR)friendlyName, 512, &retBufSize);
        if (ret)
        {
            m_cmbVideo.AddString(friendlyName);
        }
        USBCamera_ReleaseDevice(vDevice);
    }
    if (m_cmbVideo.GetCount() > 0)
    {
        m_cmbVideo.SetCurSel(0);
    }
}

void CDemoDlg::OnCbnDropdown_AudioDevice()
{
    m_cmbAudio.ResetContent();
    BOOL ret = FALSE;
    int nDeviceNum = 0;
    WCHAR friendlyName[512];
    DWORD retBufSize;

    ret = USBCamera_EnumAudioDevice(&nDeviceNum);

    for (int i = 0; i < nDeviceNum; i++)
    {
        HANDLE aDevice = NULL;
        USBCamera_GetAudioDevice(i, &aDevice);
        ret = USBCamera_GetDeviceFriendlyName(aDevice, friendlyName, 512, &retBufSize);
        if(ret)
        {
            m_cmbAudio.AddString(friendlyName);
        }
        USBCamera_ReleaseDevice(aDevice);
    }

    // Ĭ��ѡ���һ��
    if (m_cmbAudio.GetCount() > 0)
    {
        m_cmbAudio.SetCurSel(0);
    }
}

void CDemoDlg::AdapterWindow(long lWidth, long lHeight, int flag)
{
    RECT rect;
    RECT rect_temp;
    m_PreviewWindow.GetWindowRect(&rect);
    rect_temp = rect;

    ScreenToClient(&rect);
    LONG x = rect.left;  // ���
    LONG y = rect.top;

    int scale = 1;

    m_PreviewWindow.MoveWindow(x, y, lWidth*scale, lHeight*scale, TRUE);

    if(flag == 2)   // Ԥ��¼��
    {
        USBCamera_ResizeWindow(m_nPort, 0, 0, lWidth*scale, lHeight*scale);
    }

    RECT rect_main;
    this->GetWindowRect(&rect_main);
    int nWinWidth = lWidth+x+10;
    if (nWinWidth < 1000)
    {
        nWinWidth = 1000;
    }
    MoveWindow(rect_main.left, rect_main.top, nWinWidth, lHeight+rect.top+30);
}

//
void CDemoDlg::OnTimer(UINT_PTR nIDEvent)
{
    if (m_bRunning)
    {
        OnBnClickedBtnStop();
    }
    CDialog::OnTimer(nIDEvent);
}

// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialog
{
public:
    CAboutDlg();

    // �Ի�������
    enum { IDD = IDD_ABOUTBOX };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

    // ʵ��
protected:
    DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

// �¼��ص�����
void __stdcall EventSignalingCallBack(LONG m_nPort, long lEvent, long nParam1, long nParam2)
{
    switch(lEvent)
    {
    case USBCAMERA_COMPLETE:
        break;

    case USBCAMERA_DEVICE_LOST:
        if (nParam1 == 0)    // device remove
        {
            if(USBCamera_Stop(m_nPort))
            {
                USBCamera_FreeDevice(m_nPort);
            }

            OutputDebugString(TEXT("Device Remove.\n"));
        }
        else if (nParam1 == 1)    // device add
        {
            OutputDebugString(TEXT("Device Arrival.\n"));
        }
        break;
    }
}

//
void CDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
    if ((nID & 0xFFF0) == IDM_ABOUTBOX)
    {
        //CAboutDlg dlgAbout;
        //dlgAbout.DoModal();
    }
    else
    {
        CDialog::OnSysCommand(nID, lParam);
    }
}

void CDemoDlg::OnPaint()
{
    if (IsIconic())
    {
        CPaintDC dc(this); // ���ڻ��Ƶ��豸������

        SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

        // ʹͼ���ڹ����������о���
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // ����ͼ��
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
    {
        CDialog::OnPaint();
    }
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CDemoDlg::OnQueryDragIcon()
{
    return static_cast<HCURSOR>(m_hIcon);
}


//
void CDemoDlg::OnSize(UINT nType, int cx, int cy)
{
    CDialog::OnSize(nType, cx, cy);

    return;

    //     int width = 0, height = 0;
    //     RECT rc;
    //     GetClientRect(&rc);
    // 
    //     width = rc.right - rc.left - 40;
    //     height = rc.bottom - rc.top - 170; 
    // 
    //     // 
    //     RECT dstRect;
    //     ::GetClientRect(m_PreviewWindow.GetSafeHwnd(), &dstRect);
    // 
    //     ::MoveWindow(m_PreviewWindow.GetSafeHwnd(), 20, 150, width, height, 1);
    // 
    //     if(fPreviewing || fCapturing)
    //     {
    //         // Resize 
    //         USBCamera_ResizeWindow(nPort, 0, 0, width, height);
    //     }

}


void CDemoDlg::OnClose()
{
    HRESULT hr = S_OK;

    if (m_bRunning)
    {
        USBCamera_Stop(m_nPort);
        USBCamera_FreeDevice(m_nPort);
    }

    USBCamera_FreePort(m_nPort);
    m_nPort = -1;

    if (m_pWaveFormat != NULL)
    {
        USBCamera_DeleteMemory(m_pWaveFormat);
        m_pWaveFormat = NULL;
    }

    CDialog::OnClose();
}

//
void CDemoDlg::OnDestroy()
{
    CDialog::OnDestroy();
    USBCamera_UninitSDK();
}



void CDemoDlg::OnCbnSelchangeCombo2()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    
}
