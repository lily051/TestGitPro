// DemoDlg.h : ͷ�ļ�
//

#pragma once

#include "afxwin.h"

#include "USBCamera.h"


// CDemoDlg �Ի���
class CDemoDlg : public CDialog
{
// ����
public:
    CDemoDlg(CWnd* pParent = NULL);    // ��׼���캯��

    // �Ի�������
    enum { IDD = IDD_DEMO_DIALOG };

    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
    HICON m_hIcon;

    // ���ɵ���Ϣӳ�亯��
    virtual BOOL OnInitDialog();
    afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    afx_msg void OnSize(UINT nType, int cx, int cy);
    afx_msg void OnClose();
    afx_msg void OnDestroy();
    afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);

    afx_msg void OnCbnDropdown_VideoDevice();
    afx_msg void OnCbnDropdown_AudioDevice();
    afx_msg void OnTimer(UINT_PTR nIDEvent);

    afx_msg void OnBnClickedBtnStart();
    afx_msg void OnBnClickedBtnStop();
    afx_msg void OnBnClickedBtnSnapshot();

    DECLARE_MESSAGE_MAP()

private:

    void AdapterWindow(long lWidth, long lHeight, int flag);

    CStatic m_PreviewWindow;
    CButton m_btnStart;
    CButton m_btnStop;
    CButton m_btnSnapShot;

    CComboBox m_cmbVideo;   // video ѡ���
    CComboBox m_cmbAudio;   // audio ѡ���

    CComboBox m_cmbResolution; 
    CComboBox m_cmbFrameRate;

    CComboBox m_cmbPreviewType;
    CComboBox m_cmbCaptureType;

    CComboBox m_cmbCaptureTime;

    CButton m_btnUsePreview;
    CButton m_btnUseCapture;

    CButton m_btnPreviewAudio;
    CButton m_btnCaptureAudio;

    CComboBox m_cmbH264BitRate;

    CComboBox m_cmbAudioProperty;
    // ��Ƶ����
    WAVEFORMATEX *m_pWaveFormat;

    DWORD m_dwFilter;

    DWORD m_dwH264BitRate;

    DWORD m_dwFrameRate;

    DWORD m_dwCaptureTime;

    LONG  m_nPort;    // Ԥ����¼�� ����ͨ����

    BOOL  m_bRunning;

    long m_nClientWidth;   // �ͻ�����С
    long m_nClientHeight;    

    HWND m_hVideoWnd;

    static void __stdcall DecCallBack (LONG nPort, unsigned char *pBuf, long nSize, FRAME_INFO *pFrameInfo, void* pUser);

public:
    afx_msg void OnCbnSelchangeCombo2();
};
