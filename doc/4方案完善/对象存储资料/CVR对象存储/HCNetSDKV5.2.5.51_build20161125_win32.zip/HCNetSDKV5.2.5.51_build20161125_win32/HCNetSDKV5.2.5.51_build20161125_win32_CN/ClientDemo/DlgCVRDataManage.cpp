// DlgCVRDataManage.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ClientDemo.h"
#include "DlgCVRDataManage.h"
#include "afxdialogex.h"


// CDlgCVRDataManage �Ի���

IMPLEMENT_DYNAMIC(CDlgCVRDataManage, CDialogEx)

CDlgCVRDataManage::CDlgCVRDataManage(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgCVRDataManage::IDD, pParent)
    , m_strDownloadUrl(_T(""))
    , m_strFileName(_T(""))
    , m_strFilePath(_T(""))
    , m_dwFileSize(0)
    , m_iStoragePoolID(0)
    , m_strUploadUrl(_T(""))
    , m_iUploadThreadSum(1)
    , m_iDownloadThreadSum(1)
    , m_strSavePath(_T(""))
    , m_bUploadSubpackage(FALSE)
    , m_bDownloadDataCallback(FALSE)
{
    m_lServerID = -1;
    m_lDeviceIndex = -1;
    m_lUploadHandle = -1;
    m_bUpLoading = FALSE;
    m_hUpLoadThread = NULL;
    m_dwThreadId = 0;
    m_hUpLoadSendThread = NULL;
    m_dwSendThreadId = 0;
    memset(&m_struDataInfo, 0, sizeof(m_struDataInfo));

    m_bDownLoading = FALSE;
    m_lDownloadHandle = -1;
    m_hDownloadThread = NULL;
    memset(&m_struDataParam, 0, sizeof(m_struDataParam));
}

CDlgCVRDataManage::~CDlgCVRDataManage()
{
}

void CDlgCVRDataManage::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_COMBO_FILE_TYPE, m_comboFileType);
    DDX_Text(pDX, IDC_EDIT_DOWNLOAD_URL, m_strDownloadUrl);
    DDX_Text(pDX, IDC_EDIT_FILE_NAME, m_strFileName);
    DDX_Text(pDX, IDC_EDIT_FILE_PATH, m_strFilePath);
    DDX_Text(pDX, IDC_EDIT_FILE_SIZE, m_dwFileSize);
    DDX_Text(pDX, IDC_EDIT_STORAGE_POOL_ID, m_iStoragePoolID);
    DDX_Text(pDX, IDC_EDIT_UPLOAD_URL, m_strUploadUrl);
    DDX_Text(pDX, IDC_EDIT_UPLOAD_THREAD_SUM, m_iUploadThreadSum);
    DDV_MinMaxInt(pDX, m_iUploadThreadSum, 1, 32);
    DDX_Text(pDX, IDC_EDIT_DOWNLOAD_THREAD_SUM, m_iDownloadThreadSum);
    DDV_MinMaxInt(pDX, m_iDownloadThreadSum, 1, 32);
    DDX_Text(pDX, IDC_EDIT_SAVE_PATH, m_strSavePath);
    DDX_Check(pDX, IDC_CHECK_UPLOAD_SUBPACKAGE, m_bUploadSubpackage);
    DDX_Check(pDX, IDC_CHECK_DOWNLOAD_DATA_CALLBACK, m_bDownloadDataCallback);
}


BEGIN_MESSAGE_MAP(CDlgCVRDataManage, CDialogEx)
    ON_BN_CLICKED(IDC_BUTTON_BROWSE, &CDlgCVRDataManage::OnBnClickedButtonBrowse)
    ON_BN_CLICKED(IDC_BUTTON_UPLOAD, &CDlgCVRDataManage::OnBnClickedButtonUpload)
    ON_BN_CLICKED(IDC_BUTTON_DOWNLOAD, &CDlgCVRDataManage::OnBnClickedButtonDownload)
    ON_BN_CLICKED(IDC_BUTTON_SAVE_PATH_BROWSE, &CDlgCVRDataManage::OnBnClickedButtonSavePathBrowse)
END_MESSAGE_MAP()


// CDlgCVRDataManage ��Ϣ��������


void CDlgCVRDataManage::OnBnClickedButtonBrowse()
{
    // TODO:  �ڴ����ӿؼ�֪ͨ�����������
    char szLan[128] = { 0 };
    static char szFilter[] = "All File(*.*)|*.*||";
    CFileDialog dlg(TRUE, "*.*", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
    if (dlg.DoModal() == IDOK)
    {
        m_strFilePath = dlg.GetPathName();
        m_strFileName = dlg.GetFileName();
        CFile cFile;
        if (!cFile.Open(m_strFilePath, CFile::modeRead))
        {
            g_StringLanType(szLan, "���ļ�ʧ�ܻ��޴��ļ�", "Open file failed or no this file");
            AfxMessageBox(szLan);
        }
        m_dwFileSize = (DWORD)cFile.GetLength();
        cFile.Close();
        UpdateData(FALSE);
    }
}

DWORD WINAPI CDlgCVRDataManage::GetUpLoadDataThread(LPVOID pParam)
{
    CDlgCVRDataManage *pThis = (CDlgCVRDataManage*)pParam;

    DWORD dwState = 0;
    DWORD dwProgress = 0;
    char szLan[256] = { 0 };


    while (TRUE)
    {
        dwState = NET_DVR_GetUploadState(pThis->m_lUploadHandle, &dwProgress);
        if (dwState == 1)
        {
            g_StringLanType(szLan, "�ϴ��ɹ�", "Upload successfully");
            pThis->GetDlgItem(IDC_STATIC_UPLOAD_STATUC)->SetWindowText(szLan);
            pThis->m_bUpLoading = FALSE;
            g_StringLanType(szLan, "�ϴ�", "Upload");
            pThis->GetDlgItem(IDC_BUTTON_UPLOAD)->SetWindowText(szLan);
            pThis->m_bUpLoading = FALSE;

            NET_DVR_UPLOAD_FILE_RET struUploadFileRet = { 0 };
            if (NET_DVR_GetUploadResult(pThis->m_lUploadHandle, &struUploadFileRet, sizeof(struUploadFileRet)))
            {
                CString strUrl;
                strUrl.Format(_T("%s"), struUploadFileRet.sUrl);
                pThis->GetDlgItem(IDC_EDIT_UPLOAD_URL)->SetWindowText(strUrl);
            }
            else
            {
                AfxMessageBox("NET_DVR_GetUploadResult Failed");
            }
            break;
        }
        else if (dwState == 2)
        {
            g_StringLanType(szLan, "�����ϴ�,���ϴ�:", "Is uploading,progress:");
            sprintf(szLan, "%s%d", szLan, dwProgress);
            pThis->GetDlgItem(IDC_STATIC_UPLOAD_STATUC)->SetWindowText(szLan);
        }
        else if (dwState == 3)
        {
            g_StringLanType(szLan, "�ϴ�ʧ��", "Upload failed");
            pThis->GetDlgItem(IDC_STATIC_UPLOAD_STATUC)->SetWindowText(szLan);
            break;
        }
        else if (dwState == 4)
        {
            if (dwProgress == 100)
            {
                g_StringLanType(szLan, "�ϴ��ɹ�", "Upload successfully");
                pThis->GetDlgItem(IDC_STATIC_UPLOAD_STATUC)->SetWindowText(szLan);
                g_StringLanType(szLan, "�ϴ�", "UpLoad");
                pThis->GetDlgItem(IDC_BUTTON_UPLOAD)->SetWindowText(szLan);
                pThis->m_bUpLoading = FALSE;
                break;
            }
            else
            {
                g_StringLanType(szLan, "����Ͽ���״̬δ֪", "Network disconnect, status unknown");
                pThis->GetDlgItem(IDC_STATIC_UPLOAD_STATUC)->SetWindowText(szLan);
                break;
            }
        }
        if (dwState != 2 && dwState != 5)
        {
            NET_DVR_UploadClose(pThis->m_lUploadHandle);
            pThis->m_bUpLoading = FALSE;
            g_StringLanType(szLan, "�ϴ�", "UpLoad");
            pThis->GetDlgItem(IDC_BUTTON_UPLOAD)->SetWindowText(szLan);
            break;
        }
    }

    return FALSE;
}

DWORD WINAPI CDlgCVRDataManage::GetUpLoadSendDataThread(LPVOID pParam)
{
    CDlgCVRDataManage *pThis = (CDlgCVRDataManage*)pParam;

    char szOutPut[512] = { 0 };


    //�����ļ�����

    BYTE *pSendData = new BYTE[MAX_BUFFER_LEN];
    DWORD iReadLen = 0;

    while (pThis->m_bUpLoading)
    {
        memset(pSendData, 0, MAX_BUFFER_LEN);

        iReadLen = pThis->m_cSendFile.Read(pSendData, MAX_BUFFER_LEN);

        if (iReadLen <= 0)
        {
            //OutputDebugString("iReadLen==0\n");
            break;
        }
        NET_DVR_SEND_PARAM_IN struSendParamIn = { 0 };
        struSendParamIn.pSendData = pSendData;
        struSendParamIn.dwSendDataLen = iReadLen;

        if (pThis->m_lUploadHandle == NULL)
        {
            break;
        }

        int iRet = NET_DVR_UploadSend(pThis->m_lUploadHandle, &struSendParamIn, NULL);
        sprintf(szOutPut, "send %d, iReadLen[%d]\n", iRet, iReadLen);
        OutputDebugString(szOutPut);
        if (iReadLen < MAX_BUFFER_LEN || iRet != iReadLen)
        {
            break;
        }

    }

    pThis->m_cSendFile.Close();
    if (pSendData != NULL)
    {
        delete[] pSendData;
    }


    OutputDebugString("UpLoadSendThread exit \n");
    return FALSE;
}

void CDlgCVRDataManage::OnBnClickedButtonUpload()
{
    // TODO:  �ڴ����ӿؼ�֪ͨ�����������
    char szLan[128] = { 0 };
    if (m_bUpLoading == FALSE)
    {
        UpdateData(TRUE);
        char szFilePath[MAX_PATH] = { 0 };

        if (m_dwFileSize == 0)
        {
            g_StringLanType(szLan, "�ļ�Ϊ��", "File is empty");
            AfxMessageBox(szLan);
            return;
        }

        GetDlgItem(IDC_STATIC_UPLOAD_STATUC)->SetWindowText(szLan);
        memset(&m_struDataInfo, 0, sizeof(m_struDataInfo));
        m_struDataInfo.dwSize = sizeof(m_struDataInfo);
        m_struDataInfo.byFileType = m_comboFileType.GetCurSel();
        m_struDataInfo.byStoragePoolID = m_iStoragePoolID;
        m_struDataInfo.dwFileSize = m_dwFileSize;
        strncpy(m_struDataInfo.szFileName, m_strFileName, sizeof(m_struDataInfo.szFileName));

        if (m_bUploadSubpackage)
        {
            if (m_cSendFile.m_hFile != INVALID_HANDLE_VALUE)
            {
                m_cSendFile.Close();
            }
            if (!m_cSendFile.Open(m_strFilePath, CFile::modeRead))
            {
                g_StringLanType(szLan, "���ļ�ʧ�ܻ��޴��ļ�", "Open file failed or no this file");
                AfxMessageBox(szLan);
                return;
            }
            m_lUploadHandle = NET_DVR_UploadFile_V40(m_lServerID, UPLOAD_DATA_FILE, &m_struDataInfo, sizeof(m_struDataInfo), NULL, NULL, 0);
        }
        else
        {
            strcpy(szFilePath, m_strFilePath);
            m_lUploadHandle = NET_DVR_UploadFile_V40(m_lServerID, UPLOAD_DATA_FILE, &m_struDataInfo, sizeof(m_struDataInfo), szFilePath, NULL, 0);
        }


        if (m_lUploadHandle < 0)
        {
            g_StringLanType(szLan, "�����ϴ�ʧ��", "UPLOAD_PICTURE_FILE Upload Failed");
            sprintf(szLan, "%s %s %d", szLan, NET_DVR_GetErrorMsg(), NET_DVR_GetLastError());
            AfxMessageBox(szLan);
            return;
        }

        m_bUpLoading = TRUE;

        if (m_bUploadSubpackage)
        {
            m_hUpLoadSendThread = CreateThread(NULL, 0, LPTHREAD_START_ROUTINE(GetUpLoadSendDataThread), this, 0, &m_dwSendThreadId);
            if (m_hUpLoadSendThread == NULL)
            {
                m_bUpLoading = FALSE;
                g_StringLanType(szLan, "�򿪷����ļ��߳�ʧ��!", "open UpLoad thread Fail!");
                AfxMessageBox(szLan);
                return;
            }
        }

        m_hUpLoadThread = CreateThread(NULL, 0, LPTHREAD_START_ROUTINE(GetUpLoadDataThread), this, 0, &m_dwThreadId);
        if (m_hUpLoadThread == NULL)
        {
            m_bUpLoading = FALSE;
            g_StringLanType(szLan, "�򿪳����ļ��߳�ʧ��!", "open UpLoad thread Fail!");
            AfxMessageBox(szLan);
            return;
        }

        g_StringLanType(szLan, "ֹͣ�ϴ�", "Stop UpLoad");
        GetDlgItem(IDC_BUTTON_UPLOAD)->SetWindowText(szLan);
    }
    else
    {
        NET_DVR_UploadClose(m_lUploadHandle);
        m_bUpLoading = FALSE;
        g_StringLanType(szLan, "�ϴ�", "UpLoad");
        GetDlgItem(IDC_BUTTON_UPLOAD)->SetWindowText(szLan);
    }
    UpdateData(FALSE);
}

BOOL fDownloadDataFile(LONG lHandle, NET_DOWNLOAD_CB_INFO *pCBInfo, void *pUserData)
{
    CDlgCVRDataManage* pThis = (CDlgCVRDataManage*)pUserData;

    char szLan[128] = { 0 };

    if (pThis->m_cRecvFile == CFile::hFileNull)
    {
        if (!pThis->m_cRecvFile.Open(pThis->m_strSavePath, CFile::modeCreate | CFile::modeWrite))
        {
            g_StringLanType(szLan, "���ļ�ʧ�ܻ��޴��ļ�", "Open file failed or no this file");
            AfxMessageBox(szLan);
            return FALSE;
        }
    }
    pThis->m_cRecvFile.Write(pCBInfo->pData, pCBInfo->dwDataLen);

    return TRUE;
}

DWORD GetDownloadDataFileThread(LPVOID pParam)
{
    CDlgCVRDataManage *pThis = (CDlgCVRDataManage*)pParam;

    DWORD dwState = 0;
    DWORD dwProgress = 0;
    char szLan[256] = { 0 };

    while (TRUE)
    {
        dwState = NET_DVR_GetDownloadState(pThis->m_lDownloadHandle, &dwProgress);
        if (dwState == 1)
        {
            g_StringLanType(szLan, "���سɹ�", "Download successfully");
            pThis->GetDlgItem(IDC_STATIC_DOWNLOAD_STATUC)->SetWindowText(szLan);
            pThis->m_bDownLoading = FALSE;
            g_StringLanType(szLan, "����", "Download");
            pThis->GetDlgItem(IDC_BUTTON_DOWNLOAD)->SetWindowText(szLan);
            pThis->m_bDownLoading = FALSE;
            break;
        }
        else if (dwState == 2)
        {
            g_StringLanType(szLan, "��������,������:", "Is Downloading,progress:");
            sprintf(szLan, "%s%d", szLan, dwProgress);
            pThis->GetDlgItem(IDC_STATIC_DOWNLOAD_STATUC)->SetWindowText(szLan);
        }
        else if (dwState == 3)
        {
            g_StringLanType(szLan, "����ʧ��", "Download failed");
            pThis->GetDlgItem(IDC_STATIC_DOWNLOAD_STATUC)->SetWindowText(szLan);
            break;
        }
        else if (dwState == 4)
        {
            if (dwProgress == 100)
            {
                g_StringLanType(szLan, "���سɹ�", "Download successfully");
                pThis->GetDlgItem(IDC_STATIC_DOWNLOAD_STATUC)->SetWindowText(szLan);
                g_StringLanType(szLan, "����", "DownLoad");
                pThis->GetDlgItem(IDC_BUTTON_DOWNLOAD)->SetWindowText(szLan);
                pThis->m_bDownLoading = FALSE;
                break;
            }
            else
            {
                g_StringLanType(szLan, "����Ͽ���״̬δ֪", "Network disconnect, status unknown");
                pThis->GetDlgItem(IDC_STATIC_DOWNLOAD_STATUC)->SetWindowText(szLan);
                break;
            }
        }

        if (dwState != 2 && dwState != 5)
        {
            NET_DVR_StopDownload(pThis->m_lDownloadHandle);
            pThis->m_bDownLoading = FALSE;
            g_StringLanType(szLan, "����", "Download");
            pThis->GetDlgItem(IDC_BUTTON_DOWNLOAD)->SetWindowText(szLan);
            break;
        }
    }

    if (pThis->m_cRecvFile != CFile::hFileNull)
    {
        pThis->m_cRecvFile.Close();
    }

    return FALSE;
}

void CDlgCVRDataManage::OnBnClickedButtonDownload()
{
    // TODO:  �ڴ����ӿؼ�֪ͨ�����������
    char szLan[128] = { 0 }, szSavePath[1024] = { 0 };
    if (m_bDownLoading == FALSE)
    {
        UpdateData(TRUE);
        GetDlgItem(IDC_STATIC_DOWNLOAD_STATUC)->SetWindowText(szLan);

        memset(&m_struDataParam, 0, sizeof(m_struDataParam));
        m_struDataParam.dwSize = sizeof(m_struDataParam);
        strncpy((char*)m_struDataParam.sUrl, m_strDownloadUrl, sizeof(m_struDataParam.sUrl));

        if (m_bDownloadDataCallback)
        {
            m_struDataParam.fnDownloadDataCB = fDownloadDataFile;
            m_struDataParam.pUserData = this;
            m_lDownloadHandle = NET_DVR_StartDownload(m_lServerID, NET_SDK_DOWNLOAD_DATA_FILE, &m_struDataParam, sizeof(m_struDataParam), NULL);
        }
        else
        {
            sprintf(szSavePath, "%s", m_strSavePath);
            m_struDataParam.fnDownloadDataCB = NULL;
            m_struDataParam.pUserData = NULL;
            m_lDownloadHandle = NET_DVR_StartDownload(m_lServerID, NET_SDK_DOWNLOAD_DATA_FILE, &m_struDataParam, sizeof(m_struDataParam), szSavePath);
        }

        if (m_lDownloadHandle < 0)
        {
            NET_DVR_StopDownloadFile(m_lDownloadHandle);
            AfxMessageBox("NET_SDK_DOWNLOAD_DATA_FILE Download Failed");
            return;
        }

        DWORD dwThreadId = 0;
        m_hDownloadThread = CreateThread(NULL, 0, LPTHREAD_START_ROUTINE(GetDownloadDataFileThread), this, 0, &dwThreadId);
        if (m_hDownloadThread == NULL)
        {
            char szLan[256] = { 0 };
            g_StringLanType(szLan, "�������ļ��߳�ʧ��!", "open DownLoad thread Fail!");
            AfxMessageBox(szLan);
            return;
        }
        g_StringLanType(szLan, "ֹͣ����", "Stop DownLoad");
        GetDlgItem(IDC_BUTTON_DOWNLOAD)->SetWindowText(szLan);
        m_bDownLoading = TRUE;
    }
    else
    {
        NET_DVR_StopDownload(m_lDownloadHandle);
        m_bDownLoading = FALSE;
        g_StringLanType(szLan, "����", "DownLoad");
        GetDlgItem(IDC_BUTTON_DOWNLOAD)->SetWindowText(szLan);
    }
    UpdateData(FALSE);
}

CString BrowseFolder(HWND hWnd, LPCTSTR lpTitle)
{

    char szPath[MAX_PATH] = { 0 };
    BROWSEINFO m_bi;

    m_bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_STATUSTEXT;
    m_bi.hwndOwner = hWnd;
    m_bi.pidlRoot = NULL;
    m_bi.lpszTitle = lpTitle;
    m_bi.lpfn = NULL;
    m_bi.lParam = NULL;
    m_bi.pszDisplayName = szPath;

    LPITEMIDLIST pidl = ::SHBrowseForFolder(&m_bi);
    if (pidl)
    {
        if (!::SHGetPathFromIDList(pidl, szPath))
        {
            szPath[0] = 0;
        }

        IMalloc * pMalloc = NULL;
        if (SUCCEEDED(::SHGetMalloc(&pMalloc)))  // ȡ��IMalloc�������ӿ�
        {
            pMalloc->Free(pidl);    // �ͷ��ڴ�
            pMalloc->Release();       // �ͷŽӿ�
        }
    }
    return szPath;
}

void CDlgCVRDataManage::OnBnClickedButtonSavePathBrowse()
{
    // TODO:  �ڴ����ӿؼ�֪ͨ�����������
    CString strFilePath = _T("");
    strFilePath = BrowseFolder(this->m_hWnd, "ѡ��Ŀ¼");
    if (strFilePath.IsEmpty())
    {
        MessageBox("�����ļ�·������Ϊ��");
        return;
    }
    m_strSavePath = strFilePath + _T("\\") +m_strFileName;
    GetDlgItem(IDC_EDIT_SAVE_PATH)->SetWindowText(m_strSavePath);
}
