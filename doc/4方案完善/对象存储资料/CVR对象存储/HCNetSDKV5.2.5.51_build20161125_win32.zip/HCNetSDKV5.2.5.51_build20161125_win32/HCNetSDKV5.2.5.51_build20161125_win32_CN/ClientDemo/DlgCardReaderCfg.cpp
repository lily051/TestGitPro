// DlgCardReaderCfg.cpp : implementation file
//

#include "stdafx.h"
#include "clientdemo.h"
#include "DlgCardReaderCfg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgCardReaderCfg dialog


CDlgCardReaderCfg::CDlgCardReaderCfg(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCardReaderCfg::IDD, pParent)
    ,m_iUserID(0)
    ,m_iDeviceID(0)
    , m_iLocalControllerID(0)
    , m_iLocalControllerReaderID(0)
    , m_bUseLocalController(FALSE)
{
	//{{AFX_DATA_INIT(CDlgCardReaderCfg)
	m_BEnable = FALSE;
	m_BEnableFailAlarm = FALSE;
	m_dwCardReaderNo = 1;
	m_dwSwipeInterval = 0;
	m_dwPressTimeOut = 0;
	m_dwMaxReadCardFailNum = 0;
	m_BEnableTamperCheck = FALSE;
	m_dwOfflineCheckTime = 0;
    m_byFingerPrintCheckLevel=0;
	//}}AFX_DATA_INIT
}


void CDlgCardReaderCfg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgCardReaderCfg)
	DDX_Control(pDX, IDC_COMB_AC_CREADER_TYPE, m_cmbType);
	DDX_Control(pDX, IDC_COMB_AC_CREADER_BUZZERPOLARITY, m_cmbBuzzerPolarity);
	DDX_Control(pDX, IDC_COMB_AC_CREADER_ERRORLED, m_cmbErrorLed);
	DDX_Control(pDX, IDC_COMB_AC_CREADER_OKLED, m_cmbOKLed);
	DDX_Check(pDX, IDC_CHK_AC_READER_ENABLE, m_BEnable);
	DDX_Check(pDX, IDC_CHK_AC_READER_ENABLEFAILALARM, m_BEnableFailAlarm);
	DDX_Text(pDX, IDC_EDT_AC_CARDERCFG_NO, m_dwCardReaderNo);
	DDX_Text(pDX, IDC_EDT_AC_CARDERCFG_SWIPEINTERVAL, m_dwSwipeInterval);
	DDX_Text(pDX, IDC_EDT_AC_CARDERCFG_PRESSTIMEOUT, m_dwPressTimeOut);
	DDX_Text(pDX, IDC_EDT_AC_CARDERCFG_MAXREADCARDFAILNUM, m_dwMaxReadCardFailNum);
	DDX_Check(pDX, IDC_CHK_AC_READER_ENABLETAMPERCHECK, m_BEnableTamperCheck);
	DDX_Text(pDX, IDC_EDT_AC_OFFLINE_CHECKTIME, m_dwOfflineCheckTime);
    DDX_Text(pDX, IDC_EDIT_CHECK_LEVEL, m_byFingerPrintCheckLevel);
	//}}AFX_DATA_MAP
    DDX_Control(pDX, IDC_COMB_AC_CARDREADER_CHANNEL, m_cmbCardReaderChannel);
    DDX_Text(pDX, IDC_EDT_ACDC_LOCALCONTROLLERID, m_iLocalControllerID);
    DDX_Text(pDX, IDC_EDT_ACDC_LOCALCONTROLLER_READERID, m_iLocalControllerReaderID);
    DDX_Check(pDX, IDC_CHK_ACDC_USELOCALCONTROLLER, m_bUseLocalController);
}


BEGIN_MESSAGE_MAP(CDlgCardReaderCfg, CDialog)
	//{{AFX_MSG_MAP(CDlgCardReaderCfg)
	ON_BN_CLICKED(IDC_BUT_AC_CARDREADERCFG_GET, OnButGet)
	ON_BN_CLICKED(IDC_BUT_AC_CARDREADERCFG_SET, OnButSet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCardReaderCfg message handlers

void CDlgCardReaderCfg::OnButGet() 
{
	// TODO: Add your control notification handler code here
    UpdateData(TRUE); 
    NET_DVR_CARD_READER_CFG struReaderCfg = {0}; 
    DWORD dwRet; 
    if ( !NET_DVR_GetDVRConfig(m_iUserID, NET_DVR_GET_CARD_READER_CFG, m_dwCardReaderNo, &struReaderCfg, sizeof(struReaderCfg),  &dwRet))
    {
        g_pMainDlg->AddLog(m_iDeviceID, OPERATION_FAIL_T, "NET_DVR_GET_CARD_READER_CFG");
        MessageBox("NET_DVR_GET_CARD_READER_CFG Fail"); 
        return ; 
    }
    g_pMainDlg->AddLog(m_iDeviceID, OPERATION_SUCC_T, "NET_DVR_GET_CARD_READER_CFG");
    m_BEnable = struReaderCfg.byEnable; 
    m_BEnableFailAlarm = struReaderCfg.byEnableFailAlarm; 
    m_cmbType.SetCurSel(struReaderCfg.byCardReaderType);
    m_cmbOKLed.SetCurSel(struReaderCfg.byOkLedPolarity); 
    m_cmbErrorLed.SetCurSel(struReaderCfg.byErrorLedPolarity); 
    m_cmbBuzzerPolarity.SetCurSel(struReaderCfg.byBuzzerPolarity); 
    m_dwSwipeInterval = struReaderCfg.bySwipeInterval; 
    m_dwPressTimeOut = struReaderCfg.byPressTimeout; 
    m_dwMaxReadCardFailNum = struReaderCfg.byMaxReadCardFailNum; 
    m_BEnableTamperCheck = struReaderCfg.byEnableTamperCheck; 
    m_dwOfflineCheckTime = struReaderCfg.byOfflineCheckTime; 
    m_byFingerPrintCheckLevel = struReaderCfg.byFingerPrintCheckLevel;

    m_bUseLocalController = struReaderCfg.byUseLocalController;
    m_iLocalControllerID = struReaderCfg.wLocalControllerID;
    m_iLocalControllerReaderID = struReaderCfg.wLocalControllerReaderID;
    m_cmbCardReaderChannel.SetCurSel(struReaderCfg.wCardReaderChannel);

	UpdateData(FALSE); 
}

void CDlgCardReaderCfg::OnButSet() 
{
	// TODO: Add your control notification handler code here
    UpdateData(TRUE); 
    NET_DVR_CARD_READER_CFG struReaderCfg = {0}; 
    struReaderCfg.dwSize = sizeof(struReaderCfg);
    struReaderCfg.byEnable = m_BEnable;
    struReaderCfg.byEnableFailAlarm = m_BEnableFailAlarm;
    struReaderCfg.byCardReaderType = m_cmbType.GetCurSel();
    struReaderCfg.byOkLedPolarity = m_cmbOKLed.GetCurSel(); 
    struReaderCfg.byErrorLedPolarity = m_cmbErrorLed.GetCurSel(); 
    struReaderCfg.byBuzzerPolarity = m_cmbBuzzerPolarity.GetCurSel(); 
    struReaderCfg.bySwipeInterval = (BYTE) m_dwSwipeInterval; 
    struReaderCfg.byPressTimeout = (BYTE) m_dwPressTimeOut;
    struReaderCfg.byMaxReadCardFailNum = (BYTE)m_dwMaxReadCardFailNum;
    struReaderCfg.byEnableTamperCheck = m_BEnableTamperCheck; 
    struReaderCfg.byOfflineCheckTime = (BYTE)m_dwOfflineCheckTime; 
    struReaderCfg.byFingerPrintCheckLevel = (BYTE)m_byFingerPrintCheckLevel; 

    struReaderCfg.byUseLocalController = m_bUseLocalController;
    struReaderCfg.wLocalControllerID = m_iLocalControllerID;
    struReaderCfg.wLocalControllerReaderID = m_iLocalControllerReaderID;
    struReaderCfg.wCardReaderChannel = m_cmbCardReaderChannel.GetCurSel();

    if (!NET_DVR_SetDVRConfig(m_iUserID, NET_DVR_SET_CARD_READER_CFG, m_dwCardReaderNo, &struReaderCfg, sizeof(struReaderCfg)))
    {
        g_pMainDlg->AddLog(m_iDeviceID, OPERATION_FAIL_T, "NET_DVR_SET_CARD_READER_CFG");
        MessageBox("NET_DVR_SET_CARD_READER_CFG Fail");
        return ; 
	}
    g_pMainDlg->AddLog(m_iDeviceID, OPERATION_SUCC_T, "NET_DVR_SET_CARD_READER_CFG");
}

BOOL CDlgCardReaderCfg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_iDeviceID = g_pMainDlg->GetCurDeviceIndex(); 
    m_iUserID = g_struDeviceInfo[m_iDeviceID].lLoginID; 
	// TODO: Add extra initialization here

    m_cmbType.ResetContent();
    m_cmbType.InsertString(0,"cannot");
    m_cmbType.InsertString(1,"DS-K110XM/MK/C/CK");
    m_cmbType.InsertString(2,"DS-K192AM/AMP");
    m_cmbType.InsertString(3,"DS-K192BM/BMP");
    m_cmbType.InsertString(4,"DS-K182AM/AMP");
    m_cmbType.InsertString(5,"DS-K182BM/BMP");
    m_cmbType.InsertString(6,"DS-K182AMF/ACF");
    m_cmbType.InsertString(7,"Wiegand/Offline");
    m_cmbType.InsertString(8,"DS-K1101M/MK");
    m_cmbType.InsertString(9,"DS-K1101C/CK");
    m_cmbType.InsertString(10,"DS-K1102M/MK/M-A");
    m_cmbType.InsertString(11,"DS-K1102C/CK");
    m_cmbType.InsertString(12,"DS-K1103M/MK");
    m_cmbType.InsertString(13,"DS-K1103C/CK");
    m_cmbType.InsertString(14,"DS-K1104M/MK");
    m_cmbType.InsertString(15,"DS-K1104C/CK");
    m_cmbType.InsertString(16,"DS-K1102S/SK/S-A");
    m_cmbType.InsertString(17,"DS-K1102G/GK");
    m_cmbType.InsertString(18,"DS-K1100S-B");
    m_cmbType.InsertString(19,"DS-K1102EM/EMK");
    m_cmbType.InsertString(20,"DS-K1102E/EK");
    m_cmbType.InsertString(21,"DS-K1200EF");
    m_cmbType.InsertString(22,"DS-K1200MF");
    m_cmbType.InsertString(23,"DS-K1200CF");
    m_cmbType.InsertString(24,"DS-K1300EF");
    m_cmbType.InsertString(25,"DS-K1300MF");
    m_cmbType.InsertString(26,"DS-K1300CF");
    m_cmbType.InsertString(27,"DS-K1105E");
    m_cmbType.InsertString(28,"DS-K1105M");
    m_cmbType.InsertString(29,"DS-K1105C");
    m_cmbType.InsertString(30,"DS-K182AMF");
    m_cmbType.InsertString(31,"DS-K196AMF");
    m_cmbType.InsertString(32,"DS-K194AMP");
    m_cmbType.InsertString(33,"DS-K1T200EF/EF-C/MF/MF-C/CF/CF-C");
    m_cmbType.InsertString(34,"DS-K1T300EF/EF-C/MF/MF-C/CF/CF-C");
    m_cmbType.InsertString(35,"DS-K1T105E/E-C/M/M-C/C/C-C");
    m_cmbType.InsertString(36, "DS-K1T803F/MF/SF/EF");
    m_cmbType.InsertString(37, "DS-K1A801F/MF/SF/EF");
    m_cmbType.InsertString(38, "DS-K1107M/MK");
    m_cmbType.InsertString(39, "DS-K1107E/EK");
    m_cmbType.InsertString(40, "DS-K1107S/SK");
    m_cmbType.InsertString(41, "DS-K1108M/MK");
    m_cmbType.InsertString(42, "DS-K1108E/EK");
    m_cmbType.InsertString(43, "DS-K1108S/SK");
    m_cmbType.InsertString(44, "DS-K1200F");
    m_cmbType.InsertString(45, "DS-K1S110-I");
    m_cmbType.InsertString(46, "DS-K1T200M-PG/PGC");
    m_cmbType.InsertString(47, "DS-K1T200M-PZ/PZC");
    m_cmbType.InsertString(48, "DS-K1109H");

	m_cmbType.SetCurSel(0);

    m_cmbCardReaderChannel.SetCurSel(0);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
