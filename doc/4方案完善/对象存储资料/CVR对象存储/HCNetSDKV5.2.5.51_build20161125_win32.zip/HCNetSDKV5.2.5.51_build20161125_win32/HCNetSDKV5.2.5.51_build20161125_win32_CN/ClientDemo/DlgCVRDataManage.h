#pragma once
#include "afxwin.h"

#define MAX_BUFFER_LEN   (32*1024)

// CDlgCVRDataManage �Ի���

class CDlgCVRDataManage : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgCVRDataManage)

public:
	CDlgCVRDataManage(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgCVRDataManage();

// �Ի�������
	enum { IDD = IDD_DLG_CVR_DATA_MANAGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
    CComboBox m_comboFileType;
    CString m_strDownloadUrl;
    CString m_strFileName;
    CString m_strFilePath;
    DWORD m_dwFileSize;
    int m_iStoragePoolID;
    CString m_strUploadUrl;
    afx_msg void OnBnClickedButtonBrowse();
    afx_msg void OnBnClickedButtonUpload();
    afx_msg void OnBnClickedButtonDownload();
    int m_iUploadThreadSum;
    int m_iDownloadThreadSum;

    LONG m_lServerID;
    LONG m_lDeviceIndex;

    LONG m_lUploadHandle;
    BOOL m_bUpLoading;
    HANDLE m_hUpLoadThread;
    DWORD m_dwThreadId;
    HANDLE m_hUpLoadSendThread;
    DWORD m_dwSendThreadId;
    CFile m_cSendFile;
    CFile m_cRecvFile;

    NET_DVR_UPLOAD_DATA_PRARAM m_struDataInfo;
    static DWORD WINAPI GetUpLoadDataThread(LPVOID pParam);
    static DWORD WINAPI GetUpLoadSendDataThread(LPVOID pParam);
    CString m_strSavePath;

    BOOL m_bDownLoading;
    LONG m_lDownloadHandle;
    HANDLE m_hDownloadThread;
    NET_DVR_DOWNLOAD_DATA_PARAM m_struDataParam;
    afx_msg void OnBnClickedButtonSavePathBrowse();
    BOOL m_bUploadSubpackage;
    BOOL m_bDownloadDataCallback;
};
