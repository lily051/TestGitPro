// DlgCVRRemoteBackup.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ClientDemo.h"
#include "DlgCVRRemoteBackup.h"
#include "afxdialogex.h"


// CDlgCVRRemoteBackup �Ի���

IMPLEMENT_DYNAMIC(CDlgCVRRemoteBackup, CDialogEx)

void CALLBACK g_fGetRemoteBackupTaskCallback(DWORD dwType, void* lpBuffer, DWORD dwBufLen, void* pUserData);
#define WM_MSG_GET_REMOTE_BACKUP_TASK_FINISH 1003
#define WM_MSG_ADD_REMOTE_BACKUP_TASK_TOLIST 1004
#define WM_MSG_UPDATEDATA_INTERFACE   1005

CDlgCVRRemoteBackup::CDlgCVRRemoteBackup(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgCVRRemoteBackup::IDD, pParent)
    , m_strTaskID(_T(""))
{

}

CDlgCVRRemoteBackup::~CDlgCVRRemoteBackup()
{
}

void CDlgCVRRemoteBackup::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_LIST_REMOTE_BACKUP, m_listRemoteBackup);
    DDX_Control(pDX, IDC_COMBO_TYPE, m_comboType);
    DDX_Text(pDX, IDC_EDIT_TASK_ID, m_strTaskID);
}


BEGIN_MESSAGE_MAP(CDlgCVRRemoteBackup, CDialogEx)
    ON_BN_CLICKED(IDC_BUTTON_GET, &CDlgCVRRemoteBackup::OnBnClickedButtonGet)
    ON_MESSAGE(WM_MSG_GET_REMOTE_BACKUP_TASK_FINISH, OnMsgGetRemoteBackupTaskFinish)
    ON_MESSAGE(WM_MSG_ADD_REMOTE_BACKUP_TASK_TOLIST, OnMsgAddRemoteBackupTaskToList)
    ON_WM_CLOSE()
END_MESSAGE_MAP()


// CDlgCVRRemoteBackup ��Ϣ��������

BOOL CDlgCVRRemoteBackup::OnInitDialog()
{
    CDialog::OnInitDialog();

    // TODO: Add extra initialization here
    char szLan[64] = { 0 };

    m_listRemoteBackup.DeleteAllItems();
    g_StringLanType(szLan, "���", "No");
    m_listRemoteBackup.InsertColumn(0, szLan, LVCFMT_LEFT, 40);
    g_StringLanType(szLan, "����ID", "TaskID");
    m_listRemoteBackup.InsertColumn(1, szLan, LVCFMT_LEFT, 60);
    g_StringLanType(szLan, "�ļ�����", "FileIndex");
    m_listRemoteBackup.InsertColumn(2, szLan, LVCFMT_LEFT, 120);
    m_listRemoteBackup.InsertColumn(3, "url", LVCFMT_LEFT, 120);
    g_StringLanType(szLan, "��ر���״̬", "Status");
    m_listRemoteBackup.InsertColumn(4, szLan, LVCFMT_LEFT, 80);
    g_StringLanType(szLan, "����url", "BackupMachineUrl");
    m_listRemoteBackup.InsertColumn(5, szLan, LVCFMT_LEFT, 120);
    m_listRemoteBackup.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
    return TRUE;  // return TRUE unless you set the focus to a control
    // EXCEPTION: OCX Property Pages should return FALSE
}

void CALLBACK g_fGetRemoteBackupTaskCallback(DWORD dwType, void* lpBuffer, DWORD dwBufLen, void* pUserData)
{
    CDlgCVRRemoteBackup* pDlg = (CDlgCVRRemoteBackup*)pUserData;
    if (pDlg == NULL)
    {
        return;
    }
    pDlg->ProcessGetRemoteBackupTaskCallbackData(dwType, lpBuffer, dwBufLen);
}

LRESULT CDlgCVRRemoteBackup::OnMsgGetRemoteBackupTaskFinish(WPARAM wParam, LPARAM lParam)
{
    NET_DVR_UploadClose(m_lGetRemoteBackupTaskHandle);
    m_lGetRemoteBackupTaskHandle = -1;
    g_pMainDlg->AddLog(m_iDevIndex, OPERATION_SUCC_T, "NET_DVR_GET_REMOTE_BACKUP_TASK Get finish");
    return 0;
}

LRESULT CDlgCVRRemoteBackup::OnMsgAddRemoteBackupTaskToList(WPARAM wParam, LPARAM lParam)
{
    LPNET_DVR_REMOTE_BACKUP_TASK_CFG lpRemoteBackupTaskCfg = (LPNET_DVR_REMOTE_BACKUP_TASK_CFG)wParam;
    if (lpRemoteBackupTaskCfg == NULL)
    {
        return 0;
    }
    AddToRemoteBackupTaskList(*lpRemoteBackupTaskCfg);
    delete lpRemoteBackupTaskCfg;
    return 0;
}

void CDlgCVRRemoteBackup::AddToRemoteBackupTaskList(const NET_DVR_REMOTE_BACKUP_TASK_CFG& struRemoteBackupTaskInfo)
{
    char szLan[128] = { 0 };
    CString strItem = "";
    int iIndex = -1;
    iIndex = m_listRemoteBackup.GetItemCount();
    strItem.Format("%d", iIndex + 1);
    m_listRemoteBackup.InsertItem(iIndex, strItem);

    m_listRemoteBackup.SetItemText(iIndex, 1, (char *)struRemoteBackupTaskInfo.byTaskID);
    m_listRemoteBackup.SetItemText(iIndex, 2, (char *)struRemoteBackupTaskInfo.byFileIndex);
    m_listRemoteBackup.SetItemText(iIndex, 3, (char *)struRemoteBackupTaskInfo.sUrl);
    if (struRemoteBackupTaskInfo.byStatus == 0)
    {
        g_StringLanType(szLan, "δִ��", "non-execution");
        m_listRemoteBackup.SetItemText(iIndex, 4, szLan);
    }
    else if (struRemoteBackupTaskInfo.byStatus == 1)
    {
        g_StringLanType(szLan, "������", "in the backup");
        m_listRemoteBackup.SetItemText(iIndex, 4, szLan);
    }
    else if (struRemoteBackupTaskInfo.byStatus == 2)
    {
        g_StringLanType(szLan, "��ɱ���", "complete backup");
        m_listRemoteBackup.SetItemText(iIndex, 4, szLan);
    }
    else if (struRemoteBackupTaskInfo.byStatus == 3)
    {
        g_StringLanType(szLan, "����ʧ��", "backup failed");
        m_listRemoteBackup.SetItemText(iIndex, 4, szLan);
    }
    m_listRemoteBackup.SetItemText(iIndex, 5, (char *)struRemoteBackupTaskInfo.sBackupMachineUrl);
    UpdateData(FALSE);
}

void CDlgCVRRemoteBackup::ProcessGetRemoteBackupTaskCallbackData(DWORD dwType, void* lpBuffer, DWORD dwBufLen)
{
    if (dwType == NET_SDK_CALLBACK_TYPE_DATA)
    {
        LPNET_DVR_REMOTE_BACKUP_TASK_CFG lpRemoteBackupTaskCfg = new NET_DVR_REMOTE_BACKUP_TASK_CFG;
        memcpy(lpRemoteBackupTaskCfg, lpBuffer, sizeof(*lpRemoteBackupTaskCfg));
        g_pMainDlg->AddLog(m_iDevIndex, OPERATION_SUCC_T, "GetRemoteBackupTask PROCESSING %s", lpRemoteBackupTaskCfg->byTaskID);
        PostMessage(WM_MSG_ADD_REMOTE_BACKUP_TASK_TOLIST, (WPARAM)lpRemoteBackupTaskCfg, 0);
    }
    else if (dwType == NET_SDK_CALLBACK_TYPE_STATUS)
    {
        DWORD dwStatus = *(DWORD*)lpBuffer;
        if (dwStatus == NET_SDK_CALLBACK_STATUS_SUCCESS)
        {
            PostMessage(WM_MSG_GET_REMOTE_BACKUP_TASK_FINISH, 0, 0);
        }
        else if (dwStatus == NET_SDK_CALLBACK_STATUS_FAILED)
        {
            g_pMainDlg->AddLog(m_iDevIndex, OPERATION_FAIL_T, "GetRemoteBackupTask STATUS_FAILED");
        }
    }
}

void CDlgCVRRemoteBackup::OnBnClickedButtonGet()
{
    // TODO:  �ڴ����ӿؼ�֪ͨ�����������
    if (m_lGetRemoteBackupTaskHandle != -1)
    {
        NET_DVR_StopRemoteConfig(m_lGetRemoteBackupTaskHandle);
        m_lGetRemoteBackupTaskHandle = -1;
    }
    m_listRemoteBackup.DeleteAllItems();
    UpdateData(TRUE);
    NET_DVR_REMOTE_BACKUP_TASK_COND struCond = { 0 };
    struCond.dwSize = sizeof(struCond);
    struCond.byType = m_comboType.GetCurSel();
    sprintf((char*)struCond.byTaskID, "%s", m_strTaskID);

    m_lGetRemoteBackupTaskHandle = NET_DVR_StartRemoteConfig(m_lServerID, NET_DVR_GET_REMOTE_BACKUP_TASK, &struCond, sizeof(struCond), g_fGetRemoteBackupTaskCallback, this);
    if (m_lGetRemoteBackupTaskHandle == -1)
    {
        g_pMainDlg->AddLog(m_iDevIndex, OPERATION_FAIL_T, "NET_DVR_GET_REMOTE_BACKUP_TASK");
        return;
    }
    else
    {
        g_pMainDlg->AddLog(m_iDevIndex, OPERATION_SUCC_T, "NET_DVR_GET_REMOTE_BACKUP_TASK");
    }
}


void CDlgCVRRemoteBackup::OnClose()
{
    // TODO:  �ڴ�������Ϣ������������/�����Ĭ��ֵ
    if (m_lGetRemoteBackupTaskHandle != -1)
    {
        NET_DVR_StopRemoteConfig(m_lGetRemoteBackupTaskHandle);
        m_lGetRemoteBackupTaskHandle = -1;
    }
    CDialogEx::OnClose();
}
