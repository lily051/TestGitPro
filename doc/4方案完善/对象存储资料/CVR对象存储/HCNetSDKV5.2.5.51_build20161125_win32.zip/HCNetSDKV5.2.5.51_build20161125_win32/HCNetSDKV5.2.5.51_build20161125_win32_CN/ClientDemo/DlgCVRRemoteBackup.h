#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CDlgCVRRemoteBackup �Ի���

class CDlgCVRRemoteBackup : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgCVRRemoteBackup)

public:
	CDlgCVRRemoteBackup(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgCVRRemoteBackup();

// �Ի�������
	enum { IDD = IDD_DLG_CVR_REMOTE_BACKUP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
    virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
    CListCtrl m_listRemoteBackup;
    CComboBox m_comboType;
    CString m_strTaskID;
    afx_msg void OnBnClickedButtonGet();
    afx_msg LRESULT OnMsgGetRemoteBackupTaskFinish(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnMsgAddRemoteBackupTaskToList(WPARAM wParam, LPARAM lParam);

    LONG m_lServerID;
    LONG m_iDevIndex;
    LONG m_lGetRemoteBackupTaskHandle;

protected:
    void AddToRemoteBackupTaskList(const NET_DVR_REMOTE_BACKUP_TASK_CFG& struRemoteBackupTaskInfo);

public:
    void ProcessGetRemoteBackupTaskCallbackData(DWORD dwType, void* lpBuffer, DWORD dwBufLen);
    afx_msg void OnClose();
};
